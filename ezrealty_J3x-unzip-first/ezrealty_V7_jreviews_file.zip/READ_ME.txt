
************************************************************************

			jReviews Everywhere file instructions

************************************************************************


The EZ* components for Joomla 3.0x each have a jReviews everywhere file, which will allow you to integrate jReviews ratings and commenting functionality.


These files are included in with the downloads for these EZ* software products, so don't forget to download them if you'll be using jReviews.




EZ Realty jReviews everywhere file Instructions:-


1. upload the everywhere_com_ezrealty.php file if it's contained in this package via FTP to the components/com_jreviews/jreviews/models/everywhere directory

2. enable jReviews integration support in EZ Realty, which can be found in the EZ Realty configuration settings on the "Integration" tab.

3. setup jReviews and the jReviews everywhere system as per the jReviews instructions.

4. test out the frontend of EZ Realty.  You should see rating stars on the various listings page layouts, and there should be ratings stars at the top of 
   the full property details page as well as the rating/commenting form at the bottom of the full property details page.



************************************************************************


EZ Autos jReviews everywhere file Instructions:-


1. upload the everywhere_com_ezautos.php file if it's contained in this package via FTP to the components/com_jreviews/jreviews/models/everywhere directory

2. enable jReviews integration support in EZ Autos, which can be found in the EZ Autos configuration settings on the "Integration" tab.

3. setup jReviews and the jReviews everywhere system as per the jReviews instructions.

4. test out the frontend of EZ Autos.  You should see rating stars on the various listings page layouts, and there should be ratings stars at the top of 
   the full vehicle details page as well as the rating/commenting form at the bottom of the full vehicle details page.



************************************************************************


EZ Clubs jReviews everywhere file Instructions:-


1. upload the everywhere_com_ezclubs.php file if it's contained in this package via FTP to the components/com_jreviews/jreviews/models/everywhere directory

2. enable jReviews integration support in EZ Clubs, which can be found in the EZ Clubs configuration settings on the "Integration" tab.

3. setup jReviews and the jReviews everywhere system as per the jReviews instructions.

4. test out the frontend of EZ Clubs.  You should see rating stars on the various listings page layouts, and there should be ratings stars at the top of 
   the full details page as well as the rating/commenting form at the bottom of the full details page.



************************************************************************


EZ Portal jReviews everywhere file Instructions:-


1. upload the everywhere_com_ezportal.php file if it's contained in this package via FTP to the components/com_jreviews/jreviews/models/everywhere directory

2. enable jReviews integration support in EZ Portal, which can be found in the EZ Portal configuration settings on the "Integration" tab.

3. setup jReviews and the jReviews everywhere system as per the jReviews instructions.

4. test out the frontend of EZ Portal.  You should see rating stars on the various listings page layouts, and there should be ratings stars at the top of 
   the full profile details page as well as the rating/commenting form at the bottom of the full profile details page.



************************************************************************


