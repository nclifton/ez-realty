
************************************************************************

			Falang files instructions

************************************************************************


The Falang extension for translations on Joomla 3.0x uses a range of XML files known as "contentelements".  Contentelement files are associated with database tables, and lay out the fields which can be translated.

These files are included in with the downloads for the EZ Realty, EZ Autos and EZ Portal software products, so don't forget to download them if you'll be using the Falang extension for translation on your site.




EZ Realty Falang contentelement file Instructions:-


1. upload the various XML files contained in this package via FTP to the administrator/components/com_falang/contentelements directory

2. there are no special integration settings in EZ Realty - so just follow the Falang user instructions once the contentelement files have been uploaded



************************************************************************


EZ Autos Falang contentelement file Instructions:-


1. upload the various XML files contained in this package via FTP to the administrator/components/com_falang/contentelements directory

2. there are no special integration settings in EZ Autos - so just follow the Falang user instructions once the contentelement files have been uploaded



************************************************************************


EZ Portal Falang contentelement file Instructions:-


1. upload the various XML files contained in this package via FTP to the administrator/components/com_falang/contentelements directory

2. there are no special integration settings in EZ Portal - so just follow the Falang user instructions once the contentelement files have been uploaded



************************************************************************

