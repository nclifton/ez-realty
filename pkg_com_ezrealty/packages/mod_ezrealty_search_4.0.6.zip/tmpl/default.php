<?php

/**
* Module: EZ Realty Search Module
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 4.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


if ( $ezrparams->get( 'enable_bootstrap' ) ){
	JHtml::_('bootstrap.framework');
}

if ($myItemid){
	$theItemid = "&amp;Itemid=".$myItemid;
} else {
	$theItemid = '';
}

if (!$ezrparams->get('butcolour')){
	$btncolour = "btn";
} else {
	$btncolour = $ezrparams->get('butcolour');
}

if (!$ezrparams->get('butsize')){
	$btnsize = "";
} else {
	$btnsize = $ezrparams->get('butsize');
}
if (!$ezrparams->get('icon_colour')){
	$iconcolour = "icon-black";
} else {
	$iconcolour = "icon-white";
}

$searchlink = JRoute::_( 'index.php?option=com_ezrealty&amp;view=transtype&amp;id=10'.$theItemid );

?>

<script type="text/javascript">

<!--

function replaceMinCharacters() { 
var origString = document.ezrModSchForm.filter_a6minprice.value; 
var inChar = ","; 
var outChar = "" 
var newString = origString.split(inChar); 
newString = newString.join(outChar); 
document.ezrModSchForm.filter_a6minprice.value = newString;
}
function replaceMaxCharacters() { 
var origString = document.ezrModSchForm.filter_a6maxprice.value; 
var inChar = ","; 
var outChar = "" 
var newString = origString.split(inChar); 
newString = newString.join(outChar); 
document.ezrModSchForm.filter_a6maxprice.value = newString;
}

//-->

</script>

    <script language="javascript" type="text/javascript">
// <![CDATA[

function switchDynaList2( listname, source, key, orig_key, orig_val ) {
	var list = eval( 'document.ezrModSchForm.' + listname );

	// empty the list
	for (i in list.options.length) {
		list.options[i] = null;
	}
	i = 0;
	for (x in source) {
		if (source[x][0] == key) {
			opt = new Option();
			opt.value = source[x][1];
			opt.text = source[x][2];

			if ((orig_key == key && orig_val == opt.value) || i == 0) {
				opt.selected = true;
			}
			list.options[i++] = opt;
		}
	}
	list.length = i;
}

// ]]>
    </script>

<?php if ( $params->get( 'showmod_countries_select' ) == 1 && $params->get( 'showmod_suburbs_select' ) == 1 ) { ?>

    <script language="javascript" type="text/javascript">
		<!--
		var countstates2 = new Array;
		<?php
		$i = 0;
		foreach ($countstates2 as $k=>$items) {
			foreach ($items as $v) {
				echo "countstates2[".$i++."] = new Array( '$k','".addslashes( $v->value )."','".addslashes( $v->text )."' );\n\t\t";
			}
		}
		?>
		//-->
    </script>

    <script language="javascript" type="text/javascript">
		<!--
		var statelocs2 = new Array;
		<?php
		$i = 0;
		foreach ($statelocs2 as $k=>$items) {
			foreach ($items as $v) {
				echo "statelocs2[".$i++."] = new Array( '$k','".addslashes( $v->value )."','".addslashes( $v->text )."' );\n\t\t";
			}
		}
		?>
		//-->
    </script>

<?php } ?>
<?php if ( !$params->get( 'showmod_countries_select' ) && $params->get( 'showmod_suburbs_select' ) == 1 || $params->get( 'showmod_countries_select' ) && $params->get( 'showmod_suburbs_select' ) == 2 ) { ?>

    <script language="javascript" type="text/javascript">
		<!--
		var statelocs2 = new Array;
		<?php
		$i = 0;
		foreach ($statelocs2 as $k=>$items) {
			foreach ($items as $v) {
				echo "statelocs2[".$i++."] = new Array( '$k','".addslashes( $v->value )."','".addslashes( $v->text )."' );\n\t\t";
			}
		}
		?>
		//-->
    </script>

<?php } ?>

<div class="custom<?php echo $moduleclass_sfx ?>">
<br />
	<form action="<?php echo $searchlink;?>" method="post" id="ezrModSchForm" name="ezrModSchForm">
	<input type="hidden" name="option" value="com_ezrealty" />
	<input type="hidden" name="view" value="transtype" />
	<input type="hidden" name="id" value="10" />
	<?php if ($myItemid){ ?>
		<input type="hidden" name="Itemid" value="<?php echo $myItemid;?>" />
	<?php } ?>

		<div class="row-fluid">
			<div class="span12">

				<?php if ( $params->get( 'showmod_keyword_select' ) ) : ?><input type="text" name="filter_a6search" id="filter_a6search" value="" maxlength="20" class="<?php echo $bs_fieldsize;?>" placeholder="<?php echo JText::_('EZREALTY_KEYWORD');?>" /><?php endif; ?>
				<?php if ( $params->get( 'showmod_categories_select' ) ) : echo stripslashes($lists['cid']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_transtype_select' ) ) : echo stripslashes($lists['type']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_countries_select' ) == 1 && $params->get( 'showmod_suburbs_select' ) == 1 ) : echo stripslashes($lists['cnid2'] . $lists['stid2'] . $lists['locid2']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_countries_select' ) == 0 && $params->get( 'showmod_suburbs_select' ) == 1 ) : echo stripslashes($lists['stid2'] . $lists['locid2']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_countries_select' ) == 1 && $params->get( 'showmod_suburbs_select' ) == 2 ) : echo stripslashes($lists['cnid2'] . $lists['locid2']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_countries_select' ) == 0 && $params->get( 'showmod_suburbs_select' ) == 2 ) : echo stripslashes($lists['locid2']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_custom1_select' ) ) : echo stripslashes($lists['custom1']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_marketstatus_select' ) ) : echo stripslashes($lists['sold']);?><?php endif; ?>

				<?php if ( $params->get( 'showmod_sellers_select' ) ) : echo stripslashes($lists['seller']);?><?php endif; ?>

				<?php if ( $params->get( 'showmod_minmaxprice_select' ) ) {?>
					<input type="text" name="filter_a6minprice" id="filter_a6minprice" placeholder="<?php echo JText::_('EZREALTY_SEARCH_MINPRICE'); ?>" maxlength="15" onblur="replaceMinCharacters();" value="<?php echo htmlspecialchars($filter_a6minprice);?>" class="<?php echo $bs_fieldsize;?>" />
					<input type="text" name="filter_a6maxprice" id="filter_a6maxprice" placeholder="<?php echo JText::_('EZREALTY_SEARCH_MAXPRICE'); ?>" maxlength="15" onblur="replaceMaxCharacters();" value="<?php echo htmlspecialchars($filter_a6maxprice);?>" class="<?php echo $bs_fieldsize;?>" />
				<?php } ?>

				<?php if ( $params->get( 'showmod_minbedsbaths_select' ) ) { ?>
					<?php echo stripslashes($lists['minbed']);?> <?php echo stripslashes($lists['minbaths']);?>
				<?php } ?>

				<?php if ( $params->get( 'showmod_minmaxarea_select' ) ) : echo stripslashes($lists['minarea'] . $lists['maxarea']);?><?php endif; ?>
				<?php if ( $params->get( 'showmod_minmaxland_select' ) ) : echo stripslashes($lists['minland'] . $lists['maxland'] . $lists['lottype']);?><?php endif; ?>

				<?php if ( file_exists(JPATH_SITE . '/administrator/components/com_realtybookings/realtybookings.php') ) {
					if ( $ezrparams->get( 'use_realtybookings' ) && $params->get( 'showmod_dates_select' ) ) { ?>
						<?php echo JHtml::_('calendar', '', 'filter_a6begin', 'filter_a6begin', '%Y-%m-%d' , array('size'=>6, 'class'=>$bs_fieldsize, 'placeholder'=> JText::_('EZREALTY_BEGIN')));?>
						<?php echo JHtml::_('calendar', '', 'filter_a6end', 'filter_a6end', '%Y-%m-%d' , array('size'=>6, 'class'=>$bs_fieldsize, 'placeholder'=> JText::_('EZREALTY_END')));?>
					<?php } else { ?>
						<input type="hidden" name="filter_a6begin" value="" />
						<input type="hidden" name="filter_a6end" value="" />
					<?php }
				} else { ?>
					<input type="hidden" name="filter_a6begin" value="" />
					<input type="hidden" name="filter_a6end" value="" />
				<?php } ?>
		
				<button class="<?php echo $btncolour.' '.$btnsize;?>" type="submit" title="<?php echo JText::_('EZREALTY_SEARCHMOD'); ?>" onclick="this.form.submit();"><i class="icon-search <?php echo $iconcolour;?>"></i> <?php echo JText::_('EZREALTY_SEARCHMOD'); ?></button>
				<input class="btn btn-warning <?php echo $btnsize;?>" type="reset" name="<?php echo JText::_( 'EZREALTY_RESET_BTN' ); ?>" value="<?php echo JText::_( 'EZREALTY_RESET_BTN' ); ?>" />

			</div>
		</div>

	</form>
</div>
