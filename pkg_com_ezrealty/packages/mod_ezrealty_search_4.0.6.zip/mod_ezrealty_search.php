<?php

/**
* Module: EZ Realty Search Module
* FileName: mod_ezrealty_search.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 4.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

# Kill error reporting
error_reporting(0);

$language =& JFactory::getLanguage();
$language->load('com_ezrealty'); // this loads the original

require_once (JPATH_SITE.'/modules/mod_ezrealty_search/helpers/listgen.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');

$document	= &JFactory::getDocument();
$ezrparams = JComponentHelper::getParams ('com_ezrealty');
$db =& JFactory::getDBO();

$path = JURI::root();

$layout 			= $params->get( 'layout' );
$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );
$cache 				= intval( $params->get( 'cache', 0 ) );

$showmod_categories_select 		= intval( $params->get( 'showmod_categories_select', 0 ) );
$showmod_transtype_select 		= intval( $params->get( 'showmod_transtype_select', 0 ) );
$showmod_marketstatus_select 	= intval( $params->get( 'showmod_marketstatus_select', 0 ) );
$showmod_sellers_select 		= intval( $params->get( 'showmod_sellers_select', 0 ) );
$showmod_countries_select 		= intval( $params->get( 'showmod_countries_select', 0 ) );
$showmod_suburbs_select 		= intval( $params->get( 'showmod_suburbs_select', 0 ) );
$showmod_minmaxprice_select 	= intval( $params->get( 'showmod_minmaxprice_select', 0 ) );
$showmod_minbedsbaths_select 	= intval( $params->get( 'showmod_minbedsbaths_select', 0 ) );
$showmod_minmaxarea_select 		= intval( $params->get( 'showmod_minmaxarea_select', 0 ) );
$showmod_minmaxland_select 		= intval( $params->get( 'showmod_minmaxland_select', 0 ) );
$showmod_keyword_select 		= intval( $params->get( 'showmod_keyword_select', 0 ) );
$showmod_dates_select 			= intval( $params->get( 'showmod_dates_select', 0 ) );
$showmod_custom1_select 		= intval( $params->get( 'showmod_custom1_select', 0 ) );
$bs_fieldsize    				= $params->get( 'bs_fieldsize' );
$bs_selectsize    				= $params->get( 'bs_selectsize' );



// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty&view=transtype&id=10'"
	;
	$db->setQuery( $query );
	$id = $db->loadResult();
	$myItemid = $id;


$filter_a6cid  = intval(JRequest::getVar( 'filter_a6cid', '0'));
$filter_a6type  = intval(JRequest::getVar( 'filter_a6type', '0'));
$filter_a6sold  = intval(JRequest::getVar( 'filter_a6sold', '0'));
$filter_a6custom1  = JRequest::getVar( 'filter_a6custom1', '');
$filter_a6seller  = intval(JRequest::getVar( 'filter_a6seller', '0'));
$filter_a6minprice  = JRequest::getVar( 'filter_a6minprice', '');
$filter_a6maxprice  = JRequest::getVar( 'filter_a6maxprice', '');
$filter_a6minbed  = intval(JRequest::getVar( 'filter_a6minbed', '0'));
$filter_a6minbaths  = intval(JRequest::getVar( 'filter_a6minbaths', '0'));
$filter_a6minarea  = JRequest::getVar( 'filter_a6minarea', '');
$filter_a6maxarea  = JRequest::getVar( 'filter_a6maxarea', '');
$filter_a6minland  = JRequest::getVar( 'filter_a6minland', '');
$filter_a6maxland  = JRequest::getVar( 'filter_a6axland', '');
$filter_a6landtype  = JRequest::getVar( 'filter_a6landtype', '');

$filter_a6country  	= intval(JRequest::getVar( 'filter_a6country', '0'));
$filter_a6state  	= intval(JRequest::getVar( 'filter_a6state', '0'));
$filter_a6locality  = intval(JRequest::getVar( 'filter_a6locality', '0'));

$filter_a6search  = JRequest::getVar( 'filter_a6search', '');
$filter_a6begin  = JRequest::getVar( 'filter_a6begin', '');
$filter_a6end  = JRequest::getVar( 'filter_a6end', '');



		# min/max land filters
		$thefilter_a1minland = preg_replace("/[^0-9.]/", "", $filter_a6minland );
		$thefilter_a1maxland = preg_replace("/[^0-9.]/", "", $filter_a6maxland );

		$lists['minland'] = "<input type=\"text\" name=\"filter_a6minland\" id=\"filter_a6minland\" placeholder=\"". JText::_('MOD_EZREALTY_SEARCH_MINLAND')."\" value=\"". htmlspecialchars($thefilter_a6minland)."\" class=\"". $bs_fieldsize."\" onchange=\"document.adminForm.submit();\" />";
		$lists['maxland'] = "<input type=\"text\" name=\"filter_a6maxland\" id=\"filter_a6maxland\" placeholder=\"". JText::_('MOD_EZREALTY_SEARCH_MAXLAND')."\" value=\"". htmlspecialchars($thefilter_a6maxland)."\" class=\"". $bs_fieldsize."\" onchange=\"document.adminForm.submit();\" />";


		$lottype[] = JHTML::_('select.option', '0', JText::_('MOD_EZREALTY_SEARCH_LOTTYPE'));
		$lottype[] = JHTML::_('select.option', '1', EZRealtyFHelper::convertLandArea());
		$lottype[] = JHTML::_('select.option', '2', EZRealtyFHelper::convertAcreage());

		$lists['lottype'] 	= JHTML::_('select.genericlist',   $lottype, 'filter_a6landtype', 'class="'.$bs_selectsize.'" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $filter_a6landtype );



        if ( $params->get( 'showmod_categories_select' ) ) {

		// build the category filter list

			if (JFactory::getApplication()->getLanguageFilter()) {
				$where = 'd.published = 1 AND d.language in (' . $db->Quote(JFactory::getLanguage()->getTag()) . ',' . $db->Quote('*') . ')';
			} else {
				$where = 'd.published = 1';
			}

			if ($ezrparams->get('deflistorder') == 1) {
				$orderby 	= ' ORDER BY d.name';
			} else {
				$orderby 	= ' ORDER BY d.ordering';
			}

			$sql	= "SELECT d.id AS value, d.name AS text FROM #__ezrealty_catg AS d WHERE ".$where." ".$orderby;
			$db->setQuery($sql);

			if (!$db->query()) {
				echo $db->stderr();
				return;
			}

			$categorys[] = JHTML::_('select.option', '0', JText::_('EZREALTY_SEARCH_ALL_PROP_CATS'));
			$categorys = array_merge( $categorys, $db->loadObjectList() );

			$lists['cid']   = JHTML::_('select.genericlist', $categorys, 'filter_a6cid', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6cid);

		}


	// Build transaction type select list

        if ($params->get( 'showmod_transtype_select') ) {

			$typeit[] = JHTML::_('select.option',  '0', JText::_( 'EZREALTY_SEARCH_ALL_TRANS_TYPES' ) );
            if ( $ezrparams->get( 'er_usetype1') ) {
				$typeit[] = JHTML::_('select.option',  '1', JText::_( 'EZREALTY_TYPE_SALE' ) );
            }
            if ( $ezrparams->get( 'er_usetype2') ) {
				$typeit[] = JHTML::_('select.option',  '2', JText::_( 'EZREALTY_TYPE_RENTAL' ) );
            }
            if ( $ezrparams->get( 'er_usetype3') ) {
				$typeit[] = JHTML::_('select.option',  '3', JText::_( 'EZREALTY_TYPE_LEASE' ) );
            }
            if ( $ezrparams->get( 'er_usetype4') ) {
				$typeit[] = JHTML::_('select.option',  '4', JText::_( 'EZREALTY_TYPE_AUCTION' ) );
            }
            if ( $ezrparams->get( 'er_usetype5') ) {
				$typeit[] = JHTML::_('select.option',  '5', JText::_( 'EZREALTY_TYPE_SWAP' ) );
            }
            if ( $ezrparams->get( 'er_usetype6') ) {
				$typeit[] = JHTML::_('select.option',  '6', JText::_( 'EZREALTY_TYPE_TENDER' ) );
            }

			$lists['type']  = JHTML::_('select.genericlist',   $typeit, 'filter_a6type', 'class="'.$bs_selectsize.'" size="1"' , 'value', 'text', $filter_a6type );

        }

	// Build Market Status select list

    if ($params->get( 'showmod_marketstatus_select')) {

        $soldit[] = JHTML::_('select.option', 0, JText::_('EZREALTY_SEARCH_ANYMARKET') );
        if ( $ezrparams->get( 'er_usemarket1') ) {
            $soldit[] = JHTML::_('select.option', 1, JText::_('EZREALTY_DETAILS_MARKET1') );
        }
        if ( $ezrparams->get( 'er_usemarket2') ) {
            $soldit[] = JHTML::_('select.option', 2, JText::_('EZREALTY_DETAILS_MARKET2') );
        }
        if ( $ezrparams->get( 'er_usemarket3') ) {
            $soldit[] = JHTML::_('select.option', 3, JText::_('EZREALTY_DETAILS_MARKET3') );
        }
        if ( $ezrparams->get( 'er_usemarket4') ) {
            $soldit[] = JHTML::_('select.option', 4, JText::_('EZREALTY_DETAILS_MARKET4') );
        }
        if ( $ezrparams->get( 'er_usemarket5') ) {
            $soldit[] = JHTML::_('select.option', 5, JText::_('EZREALTY_DETAILS_MARKET5') );
        }
		if ( $ezrparams->get( 'er_usemarket9' ) ) {
			$soldit[] = JHTML::_('select.option',  '9', JText::_( 'EZREALTY_DETAILS_MARKET9' ) );
		}
        if ( $ezrparams->get( 'er_usemarket6') ) {
            $soldit[] = JHTML::_('select.option', 6, JText::_('EZREALTY_DETAILS_MARKET6') );
        }
        if ( $ezrparams->get( 'er_usemarket7') ) {
            $soldit[] = JHTML::_('select.option', 7, JText::_('EZREALTY_DETAILS_MARKET7') );
        }
		if ( $ezrparams->get( 'er_usemarket8' ) ) {
			$soldit[] = JHTML::_('select.option',  '8', JText::_( 'EZREALTY_DETAILS_MARKET8' ) );
		}
		if ( $ezrparams->get( 'er_usemarket10' ) ) {
			$soldit[] = JHTML::_('select.option',  '10', JText::_( 'EZREALTY_DETAILS_MARKET10' ) );
		}

			$lists['sold']  = JHTML::_('select.genericlist',   $soldit, 'filter_a6sold', 'class="'.$bs_selectsize.'" size="1"' , 'value', 'text', $filter_a6sold );
    }


        if ( $params->get( 'showmod_custom1_select' ) ) {

        // Build Custom1 select list

			if (JFactory::getApplication()->getLanguageFilter()) {
				$where = 't.published = 1 AND t.custom1 != "" AND t.language in (' . $db->Quote(JFactory::getLanguage()->getTag()) . ',' . $db->Quote('*') . ')';
			} else {
				$where = 't.published = 1 AND t.custom1 != ""';
			}

   	        $sql	= "SELECT DISTINCT t.custom1 as value, t.custom1 as text FROM #__ezrealty AS t WHERE ".$where." ORDER by t.custom1";

			$db->setQuery($sql);
			if (!$db->query()) {
				echo $db->stderr();
				return;
			}

			$custom1[] = JHTML::_('select.option', '', JText::_('EZREALTY_SEARCH_ALL_CUST1') );
			$custom1 = array_merge( $custom1, $db->loadObjectList() );

			$lists['custom1']  = JHTML::_('select.genericlist', $custom1, 'filter_a6custom1', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6custom1);

		}


		if ( $ezrparams->get( 'use_ezportal' ) == 1 && file_exists(JPATH_SITE . '/administrator/components/com_ezportal/ezportal.php')){

     	   if ( $params->get( 'showmod_sellers_select' ) ) {

			// get list of Agent/seller Profiles for the dropdown filter

				$orderby 	= ' ORDER BY c.ordering';

				$sql	= "SELECT c.uid as value, c.seller_name as text FROM #__ezportal AS c WHERE c.published=1 ".$orderby;

				$db->setQuery($sql);

				if (!$db->query()) {
					echo $db->stderr();
					return;
				}

				$sellers[] = JHTML::_('select.option', '0', JText::_('EZREALTY_ALL_SELLERS_FILTER'));
				$sellers = array_merge( $sellers, $db->loadObjectList() );

				$lists['seller']  = JHTML::_('select.genericlist', $sellers, 'filter_a6seller', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6seller);

			}
		}


        if ( $params->get( 'showmod_minbedsbaths_select' ) ) {

		// Build Bed Number select lists

			$bedlist1 = array();
			$bedlist1[] = JHTML::_('select.option',  '0', JText::_( 'EZREALTY_SEARCH_MINBEDS' ) );

			if ($ezrparams->get( 'er_usecouch')) {
				$bedlist1[] = JHTML::_('select.option',  '-2', JText::_( 'EZREALTY_COUCH' ) );
			}
			if ($ezrparams->get( 'er_usestudio')) {
				$bedlist1[] = JHTML::_('select.option',  '-1', JText::_( 'EZREALTY_STUDIO' ) );
			}

			for($i=1;$i<$ezrparams->get( 'er_maxrooms')+1;$i++){
				$bedlist1[] = JHTML::_('select.option',$i , $i);
			}
  	
			$lists['minbed'] = JHTML::_('select.genericlist', $bedlist1, 'filter_a6minbed', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6minbed);


		// Build Bathroom select list

			$bathit[] = JHTML::_('select.option', '0', JText::_('EZREALTY_SEARCH_ANY_BATHS'));
			$bathit[] = JHTML::_('select.option', '1', JText::_('EZREALTY_SEARCH_1MORE_BATHS'));
			$bathit[] = JHTML::_('select.option', '2', JText::_('EZREALTY_SEARCH_2MORE_BATHS'));
			$bathit[] = JHTML::_('select.option', '3', JText::_('EZREALTY_SEARCH_3MORE_BATHS'));
			$bathit[] = JHTML::_('select.option', '4', JText::_('EZREALTY_SEARCH_4MORE_BATHS'));
			$bathit[] = JHTML::_('select.option', '5', JText::_('EZREALTY_SEARCH_5MORE_BATHS'));

			$lists['minbaths'] = JHTML::_('select.genericlist', $bathit, 'filter_a6minbaths', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6minbaths);

		}


		if ( $params->get( 'showmod_minmaxarea_select' ) ) {

			# Build minimum floor area select list

			$thearealist[] = JHTML::_('select.option',  '', JText::_( 'EZREALTY_MIN_FLOORAREA' ) );
			if ( $ezrparams->get( 'er_arealist' ) ) {
				$tarea = str_replace( "\r\n", "", $ezrparams->get( 'er_arealist' ) );
				$someAreas = explode(";",$tarea);
				for($i = 0; $i < count($someAreas)-1; $i++){
					$vlist = str_replace( ",", "", $someAreas[$i] );
					$showlist = $someAreas[$i];
					if ($showlist != ''){
						$thearealist[] = JHTML::_('select.option',  $vlist, $showlist );
					}
				}
			}
			$lists['minarea'] 	= JHTML::_('select.genericlist',   $thearealist, 'filter_a6minarea', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text', $filter_a6minarea);

			# Build maximum floor area select list

			$themarealist[] = JHTML::_('select.option',  '', JText::_( 'EZREALTY_MAX_FLOORAREA' ) );
			if ( $ezrparams->get( 'er_arealist' ) ) {
				$mtarea = str_replace( "\r\n", "", $ezrparams->get( 'er_arealist' ) );
				$msomeAreas = explode(";",$mtarea);
				for($i < count($msomeAreas)+1; $i > 0-1; $i--){
					$mvlist = str_replace( ",", "", $msomeAreas[$i] );
					$mshowlist = $msomeAreas[$i];

					if ($mshowlist != ''){
						$themarealist[] = JHTML::_('select.option',  $mvlist, $mshowlist );
					}
				}
			}
			$lists['maxarea'] 	= JHTML::_('select.genericlist',   $themarealist, 'filter_a6maxarea', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text', $filter_a6maxarea );
		}




	if ( $params->get( 'showmod_countries_select' ) == 1 && $params->get( 'showmod_suburbs_select' ) == 1 ) {


	  # Build the Country/State/Locality chained selector list


		$javascript1 = "onchange=\"switchDynaList2( 'filter_a6state', countstates2, document.ezrModSchForm.filter_a6country.options[document.ezrModSchForm.filter_a6country.selectedIndex].value, 0, 0);\"";
		$javascript2 = "onchange=\"switchDynaList2( 'filter_a6locality', statelocs2, document.ezrModSchForm.filter_a6state.options[document.ezrModSchForm.filter_a6state.selectedIndex].value, 0, 0);\"";


		$countrys = ezrealtysearch::CountryList();


		if ( $filter_a6country == 0 ) {
			if ($countrys) {
				array_unshift ($countrys, ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLCOUNTRIES')));
			} else {
				$countrys[] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_NOCOUNTS'));
			}
			$lists['cnid2'] = ezrealtysearch::selectList( $countrys, 'filter_a6country', 'class="'.$bs_selectsize.'" size="1" '. $javascript1, 'value', 'text' );
		} else {
			$countrys[] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLCOUNTRIES'));
			$lists['cnid2'] = ezrealtysearch::selectList( $countrys, 'filter_a6country', 'class="'.$bs_selectsize.'" size="1" '. $javascript1, 'value', 'text', $filter_a6country);
		}


		// do the states

		$countstates2 		= array();
		$countstates2[-1] 	= array();
		$countstates2[-1][] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLSTATES'));

		if ($countrys) foreach($countrys as $countid) {
			$countstates2[$countid->value] = array();


			$propertys2 = ezrealtysearch::StateListByCountID($countid->value);


			if ($propertys2) $countstates2[$countid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLSTATES'));

			if ($propertys2) foreach($propertys2 as $property2) $countstates2[$countid->value][] = ezrealtysearch::makeOption( $property2->value, $property2->text );
			else $countstates2[$countid->value][] = ezrealtysearch::makeOption( "0", JText::_('EZREALTY_SORT_NOSTATES'));
			$lists['countstates2'] = $countstates2;
		}

		if ( !$filter_a6state && !$filter_a6country ) {
			$stat[] 		= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLSTATES'));
			$lists['stid2'] = ezrealtysearch::selectList( $stat, 'filter_a6state', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text' );
		} else {

			if ( $filter_a6state == 0 ) {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where1 = "\n WHERE p.published = 1 AND p.countid NOT LIKE '%com_%' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where1 = "\n WHERE p.published = 1 AND p.countid NOT LIKE '%com_%'";
				}
			} else {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where1 = "\n WHERE p.published = 1 AND p.countid=".$filter_a6country." AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where1 = "\n WHERE p.published = 1 AND p.countid=".$filter_a6country;
				}
			}


			$statelist = ezrealtysearch::StateListWhere($where1);


			$stat[] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLSTATES'));
			$stat 		= array_merge( $stat, $statelist );
			$lists['stid2'] = ezrealtysearch::selectList( $stat, 'filter_a6state', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text', $filter_a6state);
		}


		// do the localities

		$statelocs2 		= array();
		$statelocs2[-1] 	= array();
		$statelocs2[-1][] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL'));


		$states = ezrealtysearch::StateList();


		if ($states) foreach($states as $stateid) {
			$statelocs2[$stateid->value] = array();


			$propertys3 = ezrealtysearch::LocalityListByStateID($stateid->value);


			if ($propertys3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL'));

			if ($propertys3) foreach($propertys3 as $property3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( $property3->value, $property3->text );
			else $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( "0", JText::_('EZREALTY_SORT_NOSUBURBS'));
			$lists['statelocs2'] = $statelocs2;
		}

		if ( !$filter_a6locality && !$filter_a6state ) {
			$locs[] 		= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL'));
			$lists['locid2'] = ezrealtysearch::selectList( $locs, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text' );
		} else {


			if ( $filter_a6state == 0 ) {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%'";
				}
			} else {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6state' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6state'";
				}
			}


			$localitylist = ezrealtysearch::LocalityListWhere($where2);


			$locs[] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL'));
			$locs 		= array_merge( $locs, $localitylist );
			$lists['locid2'] = ezrealtysearch::selectList( $locs, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text', $filter_a6locality );
		}
	}



	if ( !$params->get( 'showmod_countries_select' ) && $params->get( 'showmod_suburbs_select' ) == 1 ) {

        # Build the State/Locality chained selector list


        $javascript2 = "onchange=\"switchDynaList2( 'filter_a6locality', statelocs2, document.ezrModSchForm.filter_a6state.options[document.ezrModSchForm.filter_a6state.selectedIndex].value, 0, 0);\"";


		$states = ezrealtysearch::StateList();


        if ( $filter_a6state == 0 ) {
            if ($states) {
                array_unshift ($states, ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLSTATES')));
            } else {
                $states[] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_NOSTATES') );
            }
            $lists['stid2'] = ezrealtysearch::selectList( $states, 'filter_a6state', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text' );
        } else {
            $lists['stid2'] = ezrealtysearch::selectList( $states, 'filter_a6state', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text', $filter_a6state);
        }

        $statelocs2 		= array();
        $statelocs2[-1] 	= array();
        $statelocs2[-1][] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );

		if ($states) foreach($states as $stateid) {
			$statelocs2[$stateid->value] = array();


			$rows3 = ezrealtysearch::LocalityListByStateID($stateid->value);


			if ($rows3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );

			if ($rows3) foreach($rows3 as $row3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( $row3->value, $row3->text );
			else $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_NOSUBURBS') );
		}

        // get list of localities

        if ( !$filter_a6locality && !$filter_a6state ) {
            $locs2a[] 		= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );
            $lists['locid2'] = ezrealtysearch::selectList( $locs2a, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text' );
        } else {


			if ( $filter_a6state == 0 ) {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%'";
				}
			} else {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6state' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6state'";
				}
			}


			$localitylist = ezrealtysearch::LocalityListWhere($where2);


			$locs2a[] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );
			$locs2a 		= array_merge( $locs2a, $localitylist );
			$lists['locid2'] = ezrealtysearch::selectList( $locs2a, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text', $filter_a6locality );
        }


	}


	if ( $params->get( 'showmod_countries_select' ) == 1 && $params->get( 'showmod_suburbs_select' ) == 2 ) {


        # Build the Country/Locality chained selector list


        $javascript2 = "onchange=\"switchDynaList2( 'filter_a6locality', statelocs2, document.ezrModSchForm.filter_a6country.options[document.ezrModSchForm.filter_a6country.selectedIndex].value, 0, 0);\"";


		$states = ezrealtysearch::CountryList();


        if ( $filter_a6country == 0 ) {
            if ($states) {
                array_unshift ($states, ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_ALLCOUNTRIES')));
            } else {
                $states[] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_NOCOUNTS') );
            }
            $lists['cnid2'] = ezrealtysearch::selectList( $states, 'filter_a6country', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text' );
        } else {
            $lists['cnid2'] = ezrealtysearch::selectList( $states, 'filter_a6country', 'class="'.$bs_selectsize.'" size="1" '. $javascript2, 'value', 'text', $filter_a6country);
        }

        $statelocs2 		= array();
        $statelocs2[-1] 	= array();
        $statelocs2[-1][] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );

		if ($states) foreach($states as $stateid) {
			$statelocs2[$stateid->value] = array();


			$rows3 = ezrealtysearch::LocalityListByStateID($stateid->value);


			if ($rows3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );

			if ($rows3) foreach($rows3 as $row3) $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( $row3->value, $row3->text );
			else $statelocs2[$stateid->value][] = ezrealtysearch::makeOption( '0', JText::_('EZREALTY_SORT_NOSUBURBS') );
		}

        // get list of localities

        if ( !$filter_a6locality && !$filter_a6country ) {
            $locs2a[] 		= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );
            $lists['locid2'] = ezrealtysearch::selectList( $locs2a, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text' );
        } else {


			if ( $filter_a6country == 0 ) {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid NOT LIKE '%com_%'";
				}
			} else {
				if (JFactory::getApplication()->getLanguageFilter()) {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6country' AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
				} else {
					$where2 = "\n WHERE p.published = 1 AND p.stateid='$filter_a6country'";
				}
			}


			$localitylist = ezrealtysearch::LocalityListWhere($where2);


			$locs2a[] 	= ezrealtysearch::makeOption( '0', JText::_('EZREALTY_LISTINGS_SORTLOCALL') );
			$locs2a 		= array_merge( $locs2a, $localitylist );
			$lists['locid2'] = ezrealtysearch::selectList( $locs2a, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"', 'value', 'text', $filter_a6locality );
        }


	}



	if ( $params->get( 'showmod_countries_select' ) == 0 && $params->get( 'showmod_suburbs_select' ) == 2 ) {


	  # Build the single Locality selector list


		$localitylist = ezrealtysearch::SuburbList();

		$loclistms[] = JHTML::_('select.option', '0', JText::_('EZREALTY_SEARCH_ALL_PROP_LOCS'));
		$loclistms = array_merge( $loclistms, $localitylist );

		$lists['locid2'] = JHTML::_('select.genericlist', $loclistms, 'filter_a6locality', 'class="'.$bs_selectsize.'" size="1"','value', 'text', $filter_a6locality);

	}


	if ( $ezrparams->get( 'enable_bootstrap' ) ){
		$document->addStyleSheet("components/com_ezrealty/assets/bootstrap.css",'text/css',"screen");
	}

require JModuleHelper::getLayoutPath('mod_ezrealty_search', $params->get('layout', 'default'));


?>

