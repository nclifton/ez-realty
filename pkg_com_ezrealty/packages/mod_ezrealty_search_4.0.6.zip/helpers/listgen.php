<?php

/**
* Module: EZ Realty Search Module
* FileName: listgen.php
* Date: 10th May 2013
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 4.0.1
* EZ Realty Version #: 7.0.0
* Author: K.J. Strickland - http://www.justjoomla.com
* Copyright 2006-2013 K.J. Strickland
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


class ezrealtysearch {

	function makeOption( $value, $text='' ) {
		$obj = new stdClass;
		$obj->value = $value;
		$obj->text = trim( $text ) ? $text : $value;
		return $obj;
	}

	function selectList ( &$arr, $tag_name, $tag_attribs, $key, $text, $selected=NULL ) {
		if (is_array($arr)){
		  reset( $arr );
		}
		$html = "\n<select name=\"$tag_name\" id=\"$tag_name\" $tag_attribs>";
		for ($i=0, $n=count( $arr ); $i < $n; $i++ ) {
			$k = $arr[$i]->$key;
			$t = $arr[$i]->$text;
			$id = isset($arr[$i]->id) ? $arr[$i]->id : null;

			$extra = '';
			$extra .= $id ? " id=\"" . $arr[$i]->id . "\"" : '';
			if (is_array( $selected )) {
				foreach ($selected as $obj) {
					$k2 = $obj->$key;
					if ($k == $k2) {
						$extra .= " selected=\"selected\"";
						break;
					}
				}
			} else {
				$extra .= ($k == $selected ? " selected=\"selected\"" : '');
			}
			$html .= "\n\t<option value=\"".$k."\"$extra>" . $t . "</option>";
		}
		$html .= "\n</select>\n";
		return $html;
	}

	function CountryList() {	

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

		if (JFactory::getApplication()->getLanguageFilter()) {
			$where = "\n WHERE q.published = 1 AND q.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
		} else {
			$where = "\n WHERE q.published = 1";
		}

		if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY q.name';
		} else {
			$orderby 	= ' ORDER BY q.ordering';
		}

		$query = "SELECT q.id AS value, q.name AS text"
		. "\n FROM #__ezrealty_country AS q"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
	}

	function StateList() {	

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

		if (JFactory::getApplication()->getLanguageFilter()) {
			$where = "\n WHERE r.published = 1 AND r.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
		} else {
			$where = "\n WHERE r.published = 1";
		}

		if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY r.name';
		} else {
			$orderby 	= ' ORDER BY r.ordering';
		}

		$query = "SELECT r.id AS value, r.name AS text"
		. "\n FROM #__ezrealty_state AS r"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
	}

	function SuburbList() {	

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

		if (JFactory::getApplication()->getLanguageFilter()) {
			$where = "\n WHERE s.published = 1 AND s.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
		} else {
			$where = "\n WHERE s.published = 1";
		}

		if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY s.ezcity';
		} else {
			$orderby 	= ' ORDER BY s.ordering';
		}

		$query = "SELECT s.id AS value, s.ezcity AS text"
		. "\n FROM #__ezrealty_locality AS s"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
	}

	function StateListByCountID($countid) {	

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

		if (JFactory::getApplication()->getLanguageFilter()) {
			$where = "\n WHERE r.published = 1 AND r.countid=".$countid." AND r.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
		} else {
			$where = "\n WHERE r.published = 1 AND r.countid=".$countid;
		}

		if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY r.name';
		} else {
			$orderby 	= ' ORDER BY r.ordering';
		}

        $query = "SELECT r.id AS value, r.name AS text"
        . "\n FROM #__ezrealty_state as r"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
	}
    
	function StateListWhere($where) {	

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

        if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY p.name';
		} else {
			$orderby 	= ' ORDER BY p.ordering';
		}

        $query = "SELECT p.id AS value, p.name AS text"
        . "\n FROM #__ezrealty_state as p"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
	}

    function LocalityListByStateID($stateid) {

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

		if (JFactory::getApplication()->getLanguageFilter()) {
			$where = "\n WHERE p.published = 1 AND p.stateid=".$stateid." AND p.language in (" . $db->Quote(JFactory::getLanguage()->getTag()) . "," . $db->Quote('*') . ")";
		} else {
			$where = "\n WHERE p.published = 1 AND p.stateid=".$stateid;
		}

		if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY p.ezcity';
		} else {
			$orderby 	= ' ORDER BY p.ordering';
		}

        $query = "SELECT p.id AS value, p.ezcity AS text"
        . "\n FROM #__ezrealty_locality AS p"
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
    }

    function LocalityListWhere($where) {

		$db =& JFactory::getDBO();
		$ezrparams = JComponentHelper::getParams ('com_ezrealty');

        if ($ezrparams->get('deflistorder') == 1) {
			$orderby 	= ' ORDER BY p.ezcity';
		} else {
			$orderby 	= ' ORDER BY p.ordering';
		}

        $query = "SELECT p.id AS value, p.ezcity AS text"
        . "\n FROM #__ezrealty_locality AS p "
		. $where
		. "\n $orderby ";
		$db->setQuery( $query );
		$lists = $db->loadObjectlist();

		return $lists;
    }


}


?>

