<?php

/**
* Module: EZ Realty MultiDisplay of Listings
* FileName: default_openhouse.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.7
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


		if ($item->ohdate >= $getnow && $item->ohdate != '0000-00-00' && $item->ohstarttime && $item->ohstarttime != '00:00:00' ) { ?>
			<div class="row-fluid">
				<div class="span12">
					<?php if ($item->ohdate && $item->ohdate >= $getnow){ ?><i class="icon-calendar <?php echo $pageiconcolour;?>"></i> <span class="ez_events"><?php echo JText::_('MOD_EZREALTY_OPENHOUSE');?> <?php echo EZRealtyFHelper::convertDate ($item->ohdate);?></span><?php } ?><br />
					<i class="icon-time <?php echo $pageiconcolour;?>"></i> <?php if ($item->ohstarttime){?><span class="ez_events-small"><?php echo EZRealtyFHelper::convertTime ($item->ohstarttime);?> - <?php } ?><?php if ($item->ohendtime){?><?php echo EZRealtyFHelper::convertTime ($item->ohendtime);?></span><?php } ?>
				</div>
			</div>
		<?php }

		if ($item->ohdate2 >= $getnow && $item->ohdate2 != '0000-00-00' && $item->ohstarttime2 && $item->ohstarttime2 != '00:00:00') { ?>
			<div class="row-fluid">
				<div class="span12">
					<?php if ($item->ohdate2 && $item->ohdate2 != '0000-00-00'){ ?><i class="icon-calendar <?php echo $pageiconcolour;?>"></i> <span class="ez_events"><?php echo JText::_('MOD_EZREALTY_OPENHOUSE');?> <?php echo EZRealtyFHelper::convertDate ($item->ohdate2);?></span><?php } ?><br />
					<i class="icon-time <?php echo $pageiconcolour;?>"></i> <?php if ($item->ohstarttime2){?><span class="ez_events-small"><?php echo EZRealtyFHelper::convertTime ($item->ohstarttime2);?> - <?php } ?><?php if ($item->ohendtime2){?><?php echo EZRealtyFHelper::convertTime ($item->ohendtime2);?></span><?php } ?>
				</div>
			</div>
		<?php } ?>

