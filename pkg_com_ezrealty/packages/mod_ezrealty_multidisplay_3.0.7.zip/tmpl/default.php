<?php

/**
* Module: EZ Realty MultiDisplay of Listings
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.7
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
JHTML::_('behavior.tooltip');

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');
require_once (JPATH_SITE.'/administrator/components/com_ezrealty/assets/helper.php' );

if (!$ezrparams->get('page_iconcolour')){
	$pageiconcolour = "ezicon-black";
} else {
	$pageiconcolour = "ezicon-white";
}

$getnow = date("Y-m-d");

if ($imgeffect == 1) {
	JHtml::_('behavior.modal');
}

if ($params->get( 'lazyload')){
	if ($disjquery == 0){
 ?>

	<script type="text/javascript" src="components/com_ezrealty/assets/jquery/jquery-1.8.3.min.js"></script>
<?php } ?>

	<script src="<?php echo JURI::root();?>modules/mod_ezrealty_multidisplay/assets/jquery.lazyload.min.js" type="text/javascript"></script>

<!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<?php
}

if ($imgeffect == 2) { ?>

<script type="text/javascript" src="<?php echo JURI::root();?>components/com_ezrealty/assets/highslide/highslide.js"></script>
<script type="text/javascript">
//<![CDATA[
hs.registerOverlay({
	html: '<div class="closebutton" onclick="return hs.close(this)" title="Close"></div>',
	position: 'top right',
	fade: 2 // fading the semi-transparent overlay looks bad in IE
});

hs.graphicsDir = '<?php echo JURI::root();?>components/com_ezrealty/assets/highslide/graphics/';
hs.wrapperClassName = 'borderless';
//]]>
</script>

<?php } ?>

<div class="container-fluid">
	<div class="row-fluid">

		<?php
		if(!empty($items)):
			foreach($items as $key=>$item):
				if($item->id):

					$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

					?>

					<div class="span<?php echo $colspan;?>" style="margin-bottom: 20px;">

						<?php

						if ($titlesource && $titlepos == '0'){

							require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_title.php');

						}

						if ( $textsource ) {

							if ( $textpos ) { ?>
	
								<div class="row-fluid">
									<div class="span6">
	
							<?php }
	
							require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_images.php');
	
							if ( $textpos ) { ?>
	
								</div>
								<div class="span6">
	
							<?php }
	
							if ( $showohdate == 1 ) {

								if ($item->ohdate >= $getnow && $item->ohdate != '0000-00-00' && $item->ohdate && $item->ohstarttime != '00:00:00' || $item->ohdate2 >= $getnow && $item->ohdate2 != '0000-00-00' && $item->ohdate && $item->ohstarttime2 != '00:00:00' ) {

									require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_openhouse.php');
	
								}
							}
	
							if ($textsource != 0){
	
								require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_desc.php');
	
							}
	
							if ( $textpos ) { ?>
	
									</div>
								</div>
	
							<?php }

						} else {

							require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_images.php');

						}

						if ($titlesource && $titlepos == '1'){

							require (JPATH_SITE.'/modules/mod_ezrealty_multidisplay/tmpl/default_title.php');

						}

						?>

					</div>

				<?php else: ?>
					</div><div class="span<?php echo $colspan;?>">
				<?php endif ;
				if(($key+1) % $colcount == 0):
				?>
					</div><div class="row-fluid">
				<?php 
				endif;
			endforeach ;
		endif;
		?>	

	</div>
</div>

<?php if ($params->get( 'lazyload')){ ?>

	<script type="text/javascript">
		jQuery.noConflict();

		jQuery("img.lazy-<?php echo $module->id;?>").lazyload({
			effect: "fadeIn"
		});	
	</script>

<?php } ?>
