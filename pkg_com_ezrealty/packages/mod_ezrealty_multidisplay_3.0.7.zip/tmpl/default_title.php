<?php

/**
* Module: EZ Realty MultiDisplay of Listings
* FileName: default_title.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.7
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

if ($titlesource == 1){
	$whichtitle = $item->proploc;
} if ($titlesource == 2){
	$whichtitle = $item->adline;
}

	$number = $item->price;

	if ( $ezrparams->get( 'er_currencycontrol' ) == 1 ) {

		if ($item->currency_format==0) {
			$formatted_price = number_format($number);
		} else if ($item->currency_format==1) {
			$formatted_price = number_format($number, 2,",",".");
		} else if ($item->currency_format==2) {
			$formatted_price = number_format($number, 0,",",".");
		} else if ($item->currency_format==3) {
			$formatted_price = number_format($number, 2,".",",");
		} else if ($item->currency_format==4) {
			$formatted_price = number_format($number, 2,","," ");
		}

	} else {

		if ($ezrparams->get( 'er_currencyformat' )==0) {
			$formatted_price = number_format($number);
		} else if ($ezrparams->get( 'er_currencyformat' )==1) {
			$formatted_price = number_format($number, 2,",",".");
		} else if ($ezrparams->get( 'er_currencyformat' )==2) {
			$formatted_price = number_format($number, 0,",",".");
		} else if ($ezrparams->get( 'er_currencyformat' )==3) {
			$formatted_price = number_format($number, 2,".",",");
		} else if ($ezrparams->get( 'er_currencyformat' )==4) {
			$formatted_price = number_format($number, 2,","," ");
		}

	}

?>

<div class="row-fluid">
	<div class="span12">

		<a href="<?php echo $link;?>">
			<span class="ez_multidisplay_title<?php echo $titlesize;?>"><?php echo stripslashes($whichtitle);?> - </span>

			<span class="ez_multidisplay_price<?php echo $titlesize;?>">

				<?php if ( $ezrparams->get( 'er_hideprice') || $ezrparams->get( 'er_hideprice')==0 && $user->id ) {
					if ( $item->freq==0 ) {
						if ( $item->showprice==0 ) {
							echo stripslashes($item->priceview);
						} else {
							echo EZRealtyHelper::convertPrice ($formatted_price, $item->currency, $item->currency_position);
						}
					}
					if ( $item->freq>0 ) {
						if ( $item->showprice==0 ) {
							echo stripslashes($item->priceview);
						} else {
							echo EZRealtyHelper::convertPrice ($formatted_price, $item->currency, $item->currency_position);
							echo "&nbsp;";
							echo EZRealtyHelper::convertFrequency ($item->freq);
						}
					}
				} else {
					echo "(".JText::_('MOD_EZREALTY_HIDEPRICE').")";
				} ?>

			</span>
		</a>

	</div>
</div>
