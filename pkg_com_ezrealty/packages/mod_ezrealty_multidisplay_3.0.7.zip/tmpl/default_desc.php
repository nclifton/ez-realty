<?php

/**
* Module: EZ Realty MultiDisplay of Listings
* FileName: default_desc.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.7
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );


if ($textsource == 1){
	$whichtext = EZRealtyFHelper::limit_ezrealtytext( $item->smalldesc,$textlength );
} else if ($textsource == 2){
	$whichtext = EZRealtyFHelper::limit_ezrealtytext( $item->propdesc,$textlength );
} else {
}

?>

<div class="row-fluid">
	<div class="span12">

		<?php echo stripslashes($whichtext); ?>
		<br />
		<a href="<?php echo $link;?>">
			<strong><?php echo JText::_('MOD_EZREALTY_READMORE');?></strong>
		</a>

	</div>
</div>
