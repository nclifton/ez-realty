<?php

/**
* Module: EZ Realty MultiDisplay of Listings
* FileName: default_images.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.7
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
JHTML::_('behavior.tooltip');

$ezrparams = JComponentHelper::getParams ('com_ezrealty');


if ($imgsource == 2){

	$image = JURI::root()."images/ezrealty/panorama/".$item->panorama;

} else if ($imgsource == 1){

	if(!EZRealtyFHelper::getTheImage($item->id) ){
		$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
	} else {
		$image = EZRealtyFHelper::convertLmodImage ($item->id);
	}

} else {

	if(!EZRealtyFHelper::getTheImage($item->id) ){
		$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
	} else {
		$image = EZRealtyFHelper::convertModuleImage ($item->id);
	}
}

if ($imgsource == 2){

	$popimage = JURI::root()."images/ezrealty/panorama/".$item->panorama;

} else {

	if(!EZRealtyFHelper::getTheImage($item->id) ){
		$popimage = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
	} else {
		$popimage = EZRealtyFHelper::convertLmodImage ($item->id);
	}
}


?>

<div class="row-fluid">
	<div class="span12">

		<div class="thumbnail">
			<div id="ezimagefade">
				<div class="ezimage-wrap">

		<?php if ($imgeffect == 1) { ?>

			<a class="modal" href="<?php echo $popimage;?>" title="<?php echo stripslashes($whichtitle);?>">
				<?php if ($params->get( 'lazyload')){ ?>
					<div class="span12 frame"><img class="span12 lazy-<?php echo $module->id;?>" src="<?php echo JURI::root();?>modules/mod_ezrealty_multidisplay/assets/img/g.gif" data-original="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></div>
					<noscript><img class="span12" src="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></noscript>
				<?php } else { ?>
					<img class="span12" src="<?php echo $image;?>"  title="<?php echo stripslashes($whichtitle);?>" alt="<?php echo stripslashes($whichtitle);?>" />
				<?php } ?>
			</a>

		<?php } else if ($imgeffect == 2) { ?>

			<a href="<?php echo $popimage;?>" class="highslide" onclick="return hs.expand(this)">
				<?php if ($params->get( 'lazyload')){ ?>
					<div class="span12 frame"><img class="span12 lazy-<?php echo $module->id;?>" src="<?php echo JURI::root();?>modules/mod_ezrealty_multidisplay/assets/img/g.gif" data-original="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></div>
					<noscript><img class="span12" src="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></noscript>
				<?php } else { ?>
					<img class="span12" src="<?php echo $image;?>"  title="<?php echo stripslashes($whichtitle);?>" alt="<?php echo stripslashes($whichtitle);?>" />
				<?php } ?>
			</a>

		<?php } else { ?>

			<a href="<?php echo $link;?>">
				<?php if ($params->get( 'lazyload')){ ?>
					<div class="span12 frame"><img class="span12 lazy-<?php echo $module->id;?>" src="<?php echo JURI::root();?>modules/mod_ezrealty_multidisplay/assets/img/g.gif" data-original="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></div>
					<noscript><img class="span12" src="<?php echo $image;?>"  alt="<?php echo stripslashes($whichtitle);?>"></noscript>
				<?php } else { ?>
					<img class="span12" src="<?php echo $image;?>"  title="<?php echo stripslashes($whichtitle);?>" alt="<?php echo stripslashes($whichtitle);?>" />
				<?php } ?>
			</a>

		<?php } ?>

				</div>
			</div>
		</div>
	</div>
</div>
