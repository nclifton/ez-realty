<?php

/**
* Module: EZ Realty Accordion
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 1.0.2
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');
require_once (JPATH_SITE.'/administrator/components/com_ezrealty/assets/helper.php' );



$num_items=ceil( count( $items ) / 1 );
if ($num_items > 0) {


$numheight = $count*41;
$contheight = $contentheight;
$totalheight = $numheight + $contheight;


// prepare the CSS
$css = '/* width of content scroller pane */

.slidorion {
	position: relative;
	width: 95%;			/* Set to slidorion width. Is equal to .slider + .accordion width */
	height: '.$totalheight.'px;			/* Set to slidorion height. Is equal to .slider and .accordion height */
	background: #CBCBCB;
	padding: 10px;
	border: 1px solid #BBB;
	box-shadow: 0 0 34px #bbb;
}

.accordion .content {
	height: '.$contheight.'px;			/* This height needs to be changed as it depends on the accordion height and number of tabs */
	font-weight: normal;
	font-size: 12px;
	line-height: 20px;
	margin: 0;
	padding: 16px;
	border: none;
	background: #d6d6d6;
	background: -moz-linear-gradient(top, #d6d6d6 0%, #ffffff 10%);
	background: -webkit-linear-gradient(top, #d6d6d6 0%,#ffffff 10%);
	background: -o-linear-gradient(top, #d6d6d6 0%,#ffffff 10%);
	background: -ms-linear-gradient(top, #d6d6d6 0%,#ffffff 10%);
	background: linear-gradient(top, #d6d6d6 0%,#ffffff 10%);
	overflow:auto;
}

';

// add the CSS to the document
$doc =& JFactory::getDocument();
$doc->addStyleDeclaration($css);

?>

<link rel="stylesheet" href="modules/mod_ezrealty_accordion/assets/css/slidorion.css" />
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,700' rel='stylesheet' type='text/css'>

<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">

<div class="container-fluid">
	<div class="row-fluid">
		<div class="span12">

			<div id="slidorion" class="slidorion">
				<div class="slider">

					<?php

					$itemcounter = 0;

					foreach($items as $item1) {

						if(!EZRealtyFHelper::getTheImage($item1->id) ){
							$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
						} else {
							$image = EZRealtyFHelper::convertModuleImage ($item1->id);
						}

						if ($imgsource == 2){

							$image = JURI::root()."images/ezrealty/panorama/".$item1->panorama;

						} else if ($imgsource == 1){

							if(!EZRealtyFHelper::getTheImage($item1->id) ){
								$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
							} else {
								$image = EZRealtyFHelper::convertLmodImage ($item1->id);
							}

						} else {

							if(!EZRealtyFHelper::getTheImage($item1->id) ){
								$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
							} else {
								$image = EZRealtyFHelper::convertModuleImage ($item1->id);
							}
						}

						$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item1->slug, $item1->catslug, '', ''));

						?>

						<div class="slide"><a href="<?php echo $link;?>"><img src="<?php echo $image;?>" width="0px" /></a></div>

					<?php

					} ?>

				</div>

				<div class="accordion">

					<?php foreach($items as $item) {

						$number = $item->price;

						if ( $ezrparams->get( 'er_currencycontrol' ) == 1 ) {

							if ($item->currency_format==0) {
								$formatted_price = number_format($number);
							} else if ($item->currency_format==1) {
								$formatted_price = number_format($number, 2,",",".");
							} else if ($item->currency_format==2) {
								$formatted_price = number_format($number, 0,",",".");
							} else if ($item->currency_format==3) {
								$formatted_price = number_format($number, 2,".",",");
							} else if ($item->currency_format==4) {
								$formatted_price = number_format($number, 2,","," ");
							}

						} else {

							if ($ezrparams->get( 'er_currencyformat' )==0) {
								$formatted_price = number_format($number);
							} else if ($ezrparams->get( 'er_currencyformat' )==1) {
								$formatted_price = number_format($number, 2,",",".");
							} else if ($ezrparams->get( 'er_currencyformat' )==2) {
								$formatted_price = number_format($number, 0,",",".");
							} else if ($ezrparams->get( 'er_currencyformat' )==3) {
								$formatted_price = number_format($number, 2,".",",");
							} else if ($ezrparams->get( 'er_currencyformat' )==4) {
								$formatted_price = number_format($number, 2,","," ");
							}

						}

						if ($imgsource == 2){

							$imagex = JURI::root()."images/ezrealty/panorama/".$item->panorama;

						} else if ($imgsource == 1){

							if(!EZRealtyFHelper::getTheImage($item->id) ){
								$imagex = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
							} else {
								$imagex = EZRealtyFHelper::convertLmodImage ($item->id);
							}

						} else {

							if(!EZRealtyFHelper::getTheImage($item->id) ){
								$imagex = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
							} else {
								$imagex = EZRealtyFHelper::convertModuleImage ($item->id);
							}
						}

						if ($titlesource == 1){
							$whichtitle = $item->proploc;
						} else if ($titlesource == 2){
							$whichtitle = $item->adline;
						} else {
							$whichtitle = $item->proploc;
						}

						if ($textsource == 1){
							$whichtext = EZRealtyFHelper::limit_ezrealtytext( $item->smalldesc,$textlength );
						} else if ($textsource == 2){
							$whichtext = EZRealtyFHelper::limit_ezrealtytext( $item->propdesc,$textlength );
						} else {
						}

						//clean any line breaks
						$thetext = str_replace( "\r\n", " ", $whichtext );

						$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

						?>

						<div class="header"><?php echo $whichtitle;?> &nbsp;

							<?php  if ($titlesource == 1){
								if ( $ezrparams->get( 'er_hideprice') || $ezrparams->get( 'er_hideprice')==0 && $user->id ) {
									if ( $item->freq==0 ) {
										if ( $item->showprice==0 ) {
											echo stripslashes($item->priceview);
										} else {
											echo EZRealtyHelper::convertPrice ($formatted_price, $item->currency, $item->currency_position);
										}
									}
									if ( $item->freq>0 ) {
										if ( $item->showprice==0 ) {
											echo stripslashes($item->priceview);
										} else {
											echo EZRealtyHelper::convertPrice ($formatted_price, $item->currency, $item->currency_position);
											echo "&nbsp;";
											echo EZRealtyHelper::convertFrequency ($item->freq);
										}
									}
								} else {
									echo "(".JText::_('MOD_EZREALTY_HIDEPRICE').")";
								}
							}
							?>

						</div>
						<div class="content">

							<?php if ($textsource){ ?>

								<div class="row-fluid">
									<div class="<?php echo $bsimage;?>">
										<a href="<?php echo $link;?>"><img src="<?php echo $imagex;?>" class="thumbnail span12" /></a>
									</div>
								<?php if ($bsimage == "span12"){ ?>
									</div>
									<div class="row-fluid">
								<?php } ?>
									<div class="<?php echo $bscontent;?>">
										<?php echo $whichtext;?>
										<br />
										<a href="<?php echo $link;?>">
											<strong><?php echo JText::_('MOD_EZREALTY_READMORE');?></strong>
										</a>
									</div>
								</div>

							<?php } else { ?>

								<div class="row-fluid">
									<div class="span12">
										<a href="<?php echo $link;?>"><img src="<?php echo $imagex;?>" class="thumbnail span12" /></a>
									</div>
								</div>

							<?php } ?>

						</div>

					<?php } ?>

				</div>
			</div>

		</div>
	</div>
</div>

</div>

<?php } ?>


<?php if ($disjquery == 0){ ?>
	<script type="text/javascript" src="components/com_ezrealty/assets/jquery/jquery-1.8.3.min.js"></script>
<?php } ?>
	<script src="modules/mod_ezrealty_accordion/assets/js/jquery.easing.js"></script>
    <script src="modules/mod_ezrealty_accordion/assets/dist/jquery.slidorion.min.js"></script>

    <script>
		jQuery.noConflict();

		jQuery(function() {
			jQuery('#slidorion').slidorion({
				hoverPause: true,
				interval: 5000,
				speed: 500,
				effect: 'slideRandom'
			});
		});
	</script>

