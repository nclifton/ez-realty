<?php

/**
* Module: EZ Realty Lists
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');


if ($listingstype == 3){

	require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_recursive.php');

} else {

	if ($ezlayout == 1) {

		require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_selector.php');

	} elseif ($ezlayout == 2) {

		require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_limenu.php');

	} elseif ($ezlayout == 3) {

		require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_four.php');

	} elseif ($ezlayout == 4) {

		require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_four.php');

	} else {

		require_once (JPATH_SITE.'/modules/mod_ezrealty_lists/tmpl/default_bullet.php');

	}

}

?>
