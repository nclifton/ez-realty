<?php

/**
* Module: EZ Realty Lists
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

?>

<div class="custom<?php echo $moduleclass_sfx ?>">
	<div class="container-fluid">

		<div class="row-fluid">
			<div class="span12">

				<form name="selectmenu" action="./">
					<select class="<?php echo $bs_selectsize;?>" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
						<option value="" selected><?php echo JText::_('MOD_EZREALTY_LISTS');?></option>

						<?php

						$num_rows=ceil( count( $rows ) / 1 );
						if ($num_rows > 0) {

							$rowcounter = 0;
							foreach($rows as $row) {

								if ($listingstype == 2){
									$thelink = JRoute::_(EzrealtyHelperRoute::getStateRoute($row->slug ));
									$thename = stripslashes($row->name);
									$thecount = EZRealtyFHelper::CountCont( $row->id, 1 );
								}
								if ($listingstype == 1){
									$thelink = JRoute::_(EzrealtyHelperRoute::getSuburbRoute($row->slug ));
									$thename = stripslashes($row->ezcity);
									$thecount = EZRealtyFHelper::CountCont( $row->id, 2 );
								}
								if ($listingstype == 0){
									$thelink = JRoute::_(EzrealtyHelperRoute::getCategoryRoute($row->slug ));
									$thename = stripslashes($row->name);
									$thecount = EZRealtyFHelper::CountCont( $row->id, 3 );
								}

								?>

								<option value="<?php echo $thelink;?>"><?php echo stripslashes($thename);?> (<?php echo $thecount; ?>)</option>

							<?php

							}
						} else {
						}

						?>

					</select>
				</form>

			</div>
		</div>

	</div>
</div>
