<?php

/**
* Module: EZ Realty Lists
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

?>

<div class="custom<?php echo $moduleclass_sfx ?>">
	<div class="container-fluid">

		<div class="row-fluid">
			<div class="span12">

				<?php
				
					if ($ezrparams->get('deflistorder') == 1) {
						$orderby1 	= ' ORDER BY aa.name';
						$orderby2 	= ' ORDER BY bb.name';
						$orderby3 	= ' ORDER BY cc.ezcity';
					} else {
						$orderby1 	= ' ORDER BY aa.ordering';
						$orderby2 	= ' ORDER BY bb.ordering';
						$orderby3 	= ' ORDER BY cc.ordering';
					}

					# Do the main database query
					$query = 'SELECT aa.*'
					.' FROM #__ezrealty_country AS aa'
					.' INNER JOIN #__ezrealty AS c ON aa.id = c.cnid'
					.' WHERE aa.published = 1'
					.' GROUP BY aa.id'
					.$orderby1;
					$database->setQuery( $query );
					$rows1 = $database->loadObjectList();
				
					if ($database->getErrorNum()) {
						echo $database->stderr();
						return false;
					}
				
					$num_rows1=ceil( count( $rows1 ) / 1 );
					if ($num_rows1 > 0) {
				
						$rowcounter1 = 0;
						foreach($rows1 as $row1) {
				
							echo "<h3>".$row1->name."</h3>";
				
				
							# Do the main database query
							$query = 'SELECT bb.*, '
							.' CASE WHEN CHAR_LENGTH(bb.alias) THEN CONCAT_WS(\':\', bb.id, bb.alias) ELSE bb.id END as stslug'
							.' FROM #__ezrealty_state AS bb'
							.' INNER JOIN #__ezrealty AS d ON bb.id = d.stid'
							.' WHERE bb.countid = '.$row1->id.' AND bb.published = 1'
							.' GROUP BY bb.id'
							.$orderby2;
							$database->setQuery( $query );
							$rows2 = $database->loadObjectList();
				
							if ($database->getErrorNum()) {
								echo $database->stderr();
								return false;
							}
				
							echo '<div class="row-fluid ezmoduleTable">';
				
							$num_rows2=ceil( count( $rows2 ) / 1 );
							if ($num_rows2 > 0) {
				
								$rowcounter2 = 0;
								foreach($rows2 as $row2) {
				
									$thelink2 = JRoute::_(EzrealtyHelperRoute::getStateRoute($row2->stslug ));
				
									if (($rowcounter2%2==0) AND ($rowcounter2<>0)) echo "</div><div class=\"row-fluid\">";
				
									?>
				
									<div class="span6 ezmoduleTd">
										<h4><a href="<?php echo $thelink2;?>"><?php echo $row2->name; ?></a></h4>
				
										<?php
				
										# Do the main database query
										$query = 'SELECT cc.*, '
										.' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(\':\', cc.id, cc.alias) ELSE cc.id END as lslug'
										.' FROM #__ezrealty_locality AS cc'
										.' INNER JOIN #__ezrealty AS e ON cc.id = e.locid'
										.' WHERE cc.stateid = '.$row2->id.' AND cc.published = 1'
										.' GROUP BY cc.id'
										.$orderby3;
										$database->setQuery( $query );
										$rows3 = $database->loadObjectList();
				
											if ($database->getErrorNum()) {
											echo $database->stderr();
											return false;
										}
				
										$cityname = "";
				
										$num_rows3=ceil( count( $rows3 ) / 1 );
										if ($num_rows3 > 0) {
				
											$rowcounter3 = 0;
											foreach($rows3 as $row3) {
				
												$thelink3 = JRoute::_(EzrealtyHelperRoute::getSuburbRoute($row3->lslug ));
				
				
												$cityname .= "<a href=\"". $thelink3 ."\">".$row3->ezcity."</a>, ";
				
											}
										}
				
										$thecities = $cityname;
										$thecitieslist = rtrim($thecities, ', ');
										echo $thecitieslist;
				
									echo '</div>';
				
									$rowcounter2++;
								}
					
								if ($rowcounter2%2<>0) {
									for ($i = 1; $i <= (2-($rowcounter2%2)); $i++) {
										echo "<div class=\"span6 ezmoduleTd\"> </div>";
									}
								}
				
							} else {
				
							}
				
							echo '</div>';
				
						}
					}
				
				?>

			</div>
		</div>

	</div>
</div>
