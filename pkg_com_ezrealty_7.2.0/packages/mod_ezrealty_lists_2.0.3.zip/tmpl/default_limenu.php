<?php

/**
* Module: EZ Realty Lists
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

if (!$ezrparams->get('page_iconcolour')){
	$pageiconcolour = "ezicon-black";
} else {
	$pageiconcolour = "ezicon-white";
}

if ($ezicon){
	$theicon = $ezicon;
} else {
	$theicon = "";
}

?>

<ul class="menu <?php echo $class_sfx;?>">

	<?php

	$num_rows=ceil( count( $rows ) / 1 );
	if ($num_rows > 0) {

		$rowcounter = 0;
		foreach($rows as $row) {

			if ($listingstype == 2){
				$thelink = JRoute::_(EzrealtyHelperRoute::getStateRoute($row->slug ));
				$thename = stripslashes($row->name);
				$thecount = EZRealtyFHelper::CountCont( $row->id, 1 );
			}
			if ($listingstype == 1){
				$thelink = JRoute::_(EzrealtyHelperRoute::getSuburbRoute($row->slug ));
				$thename = stripslashes($row->ezcity);
				$thecount = EZRealtyFHelper::CountCont( $row->id, 2 );
			}
			if ($listingstype == 0){
				$thelink = JRoute::_(EzrealtyHelperRoute::getCategoryRoute($row->slug ));
				$thename = stripslashes($row->name);
				$thecount = EZRealtyFHelper::CountCont( $row->id, 3 );
			}

			?>
			<li><a href="<?php echo $thelink;?>" class="level1 item2"><?php if ($theicon){ ?><i class="<?php echo $theicon;?> <?php echo $pageiconcolour;?>"> </i> <?php } ?><?php echo stripslashes($thename);?> (<?php echo $thecount; ?>)</a></li>

		<?php

		}
	} else {

	}

	?>

</ul>
