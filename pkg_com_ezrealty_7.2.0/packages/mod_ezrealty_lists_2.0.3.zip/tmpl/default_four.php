<?php

/**
* Module: EZ Realty Lists
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

?>

<div class="custom<?php echo $moduleclass_sfx ?>">
	<div class="container-fluid">

		<div class="row-fluid">
		
			<?php
		
			if(!empty($rows)):
				foreach($rows as $key=>$row):
					if($row->id):
		
							if ($listingstype == 2){
								$thelink = JRoute::_(EzrealtyHelperRoute::getStateRoute($row->slug ));
								$thename = stripslashes($row->name);
								$thecount = EZRealtyFHelper::CountCont( $row->id, 1 );
								$whichtext = '';
							}
							if ($listingstype == 1){
								$thelink = JRoute::_(EzrealtyHelperRoute::getSuburbRoute($row->slug ));
								$thename = stripslashes($row->ezcity);
								$thecount = EZRealtyFHelper::CountCont( $row->id, 2 );
								$whichtext = EZRealtyFHelper::limit_ezrealtytext( $row->ezcity_desc,$textlength );
							}
							if ($listingstype == 0){
								$thelink = JRoute::_(EzrealtyHelperRoute::getCategoryRoute($row->slug ));
								$thename = stripslashes($row->name);
								$thecount = EZRealtyFHelper::CountCont( $row->id, 3 );
								$whichtext = EZRealtyFHelper::limit_ezrealtytext( $row->description,$textlength );
							}
		
						?>
		
						<div class="span<?php echo $colspan;?>" style="margin-bottom: 20px;">
		
							<?php if ($titlepos == 0 && $ezlayout == 4){ ?>
								<div class="row-fluid">
									<div class="span12">
										<div class="ez_lists_title" style="text-align: center;"><a href="<?php echo $thelink;?>"><?php echo stripslashes($thename);?></a> (<?php echo $thecount; ?>)</div>
									</div>
								</div>
							<?php } ?>
		
							<div class="row-fluid">
		
								<?php if ($titlepos == 2 || $ezlayout == 3){ ?>
		
									<div class="span<?php echo $imgsize;?>">
		
								<?php } else { ?>
		
									<div class="span12">
		
								<?php } ?>
		
								<?php if ($listingstype != 2){ ?>
									<a href="<?php echo $thelink;?>"><img src="<?php echo JURI::root();?>images/<?php echo $row->image;?>" class="thumbnail span12" alt="" /></a>
								<?php } ?>
		
								</div>
		
								<?php if ($titlepos == 2 || $ezlayout == 3){ ?>
		
									<div class="span<?php echo $twidth;?>">
										<div class="ez_lists_title"><a href="<?php echo $thelink;?>"><?php echo stripslashes($thename);?></a> (<?php echo $thecount; ?>)</div>
										<?php if ($ezlayout == 3) { ?>
											<?php echo stripslashes($whichtext);?>
										<?php } ?>
									</div>
		
								<?php } ?>
		
							</div>
		
							<?php if ($titlepos == 1 && $ezlayout == 4){ ?>
								<div class="row-fluid">
									<div class="span12">
										<div class="ez_lists_title" style="text-align: center;"><a href="<?php echo $thelink;?>"><?php echo stripslashes($thename);?></a> (<?php echo $thecount; ?>)</div>
									</div>
								</div>
							<?php } ?>
		
						</div>
		
					<?php else: ?>
						</div><div class="span<?php echo $colspan;?>">
					<?php endif ;
					if(($key+1) % $colcount == 0):
					?>
						</div><div class="row-fluid">
					<?php 
					endif;
				endforeach ;
			endif;
			?>	
		
		</div>

	</div>
</div>

