<?php

/**
* Module: EZ Realty Lists
* FileName: mod_ezrealty_lists.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 2.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

# Kill error reporting
error_reporting(0);

$ezrparams = JComponentHelper::getParams ('com_ezrealty');
$database =& JFactory::getDBO();

$user =& JFactory::getUser();
$max_id = 1;;
foreach ($user->groups as $group_id)
if ($max_id < $group_id) $max_id = $group_id;
$user->gid = $max_id;

$layout 			= $params->get( 'layout' );
$moduleclass_sfx 	= $params->get( 'moduleclass_sfx' );
$class_sfx 			= $params->get( 'class_sfx' );
$cache	 			= intval( $params->get( 'cache', 0 ) );

$listingstype 		= intval( $params->get( 'listingstype', 0 ) );
$ezlayout 			= intval( $params->get( 'ezlayout', 0 ) );
$item_order 		= intval( $params->get( 'item_order', 1 ) );
$textlength 		= $params->get( 'textlength' ) ;
$imgalign 			= $params->get( 'imgalign' ) ;
$imgwidth 			= intval( $params->get( 'imgwidth', 0 ) );
$count 				= intval( $params->get( 'count', 0 ) );
$colcount 			= intval( $params->get( 'colcount', 1 ) );
$ezicon 			= $params->get( 'ezicon' ) ;
$bs_selectsize    	= $params->get( 'bs_selectsize' );
$titlepos	 		= intval( $params->get( 'titlepos', 0 ) );
$imgsize	 		= intval( $params->get( 'imgsize', 1 ) );


$colspan = "";
if ($colcount=='2'){
	$colspan = "6";
} else if ($colcount=='4'){
	$colspan = "3";
} else if ($colcount=='3'){
	$colspan = "4";
} else if ($colcount=='6'){
	$colspan = "2";
} else if ($colcount=='1'){
	$colspan = "12";
} else {
	$colspan = "12";
}


$twidth = "";
if ($imgsize=='1'){
	$twidth = "11";
} else if ($imgsize=='2'){
	$twidth = "10";
} else if ($imgsize=='3'){
	$twidth = "9";
} else if ($imgsize=='4'){
	$twidth = "8";
} else if ($imgsize=='5'){
	$twidth = "7";
} else if ($imgsize=='6'){
	$twidth = "6";
} else {
	$twidth = "11";
}



if ($listingstype == 3){


//recursive output


} else {



if ($item_order == '1'){
	$whichorder = "aa.ordering";
} else if ($item_order == '2'){
	$whichorder = "nitems DESC";
} else if ($item_order == '3'){
	$whichorder = "RAND()";
} else {
	if ($listingstype == 1){
		$whichorder = "aa.ezcity";
	} else {
		$whichorder = "aa.name";
	}
}

if ( $ezrparams->get( 'er_expmgmt')==1 ) {
	if ($ezrparams->get( 'restrict_sold')==1) {
		$currentdate=mktime(0, 0, 0, date("m"), date("d"), date("Y"));
		$whichone = "aa.published='1' AND b.published = '1' AND b.expdate>$currentdate AND b.sold != '5' AND b.sold != '9'";
	} else {
		$currentdate=mktime(0, 0, 0, date("m"), date("d"), date("Y"));
		$whichone = "aa.published='1' AND b.published = '1' AND b.expdate>$currentdate";
	}
} else {
	if ($ezrparams->get( 'restrict_sold')==1) {
		$whichone = "aa.published='1' AND b.published = '1' AND b.sold != 5 AND b.sold != 9";
	} else {
		$whichone = "aa.published='1' AND b.published = '1'";
	}
}

if ($listingstype == 2){
	if ($count < '1'){
		$howmany = "aa.name ORDER BY $whichorder";
	} else {
		$howmany = "aa.name ORDER BY $whichorder LIMIT $count";
	}
}
if ($listingstype == 1){
	if ($count < '1'){
		$howmany = "aa.ezcity ORDER BY $whichorder";
	} else {
		$howmany = "aa.ezcity ORDER BY $whichorder LIMIT $count";
	}
}
if ($listingstype == 0){
	if ($count < '1'){
		$howmany = "aa.name ORDER BY $whichorder";
	} else {
		$howmany = "aa.name ORDER BY $whichorder LIMIT $count";
	}
}


if ($listingstype == 2){

	# Do the main database query
	$query = 'SELECT aa.*, COUNT(b.stid) AS nitems,'
	.' CASE WHEN CHAR_LENGTH(aa.alias) THEN CONCAT_WS(\':\', aa.id, aa.alias) ELSE aa.id END as slug'
	.' FROM #__ezrealty_state AS aa'
	.' LEFT JOIN #__ezrealty AS b ON b.stid = aa.id'
	.' WHERE '. $whichone
	.' GROUP BY '.$howmany;

}
if ($listingstype == 1){

	# Do the main database query
	$query = 'SELECT aa.*, COUNT(b.locid) AS nitems,'
	.' CASE WHEN CHAR_LENGTH(aa.alias) THEN CONCAT_WS(\':\', aa.id, aa.alias) ELSE aa.id END as slug'
	.' FROM #__ezrealty_locality AS aa'
	.' LEFT JOIN #__ezrealty AS b ON b.locid = aa.id'
	.' WHERE '. $whichone
	.' GROUP BY '.$howmany;

}
if ($listingstype == 0){

	# Do the main database query
	$query = 'SELECT aa.*, COUNT(pc.category_id) AS nitems,'
	.' CASE WHEN CHAR_LENGTH(aa.alias) THEN CONCAT_WS(\':\', aa.id, aa.alias) ELSE aa.id END as slug'
	.' FROM #__ezrealty_catg AS aa'
	.' INNER JOIN #__ezrealty_incats AS pc ON pc.category_id = aa.id'
	.' RIGHT JOIN #__ezrealty AS b ON b.id = pc.property_id'
	.' WHERE '. $whichone
	.' GROUP BY '.$howmany;

}


//echo $query;

$database->setQuery( $query );
$rows = $database->loadObjectList();

if ($database->getErrorNum()) {
	echo $database->stderr();
	return false;
}


}


$document =& JFactory::getDocument();
$document->addStyleSheet("modules/mod_ezrealty_lists/assets/style.css",'text/css',"screen");
require JModuleHelper::getLayoutPath('mod_ezrealty_lists', $params->get('layout', 'default'));


?>