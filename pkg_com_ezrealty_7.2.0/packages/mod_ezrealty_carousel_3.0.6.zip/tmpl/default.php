<?php

/**
* Module: EZ Realty Carousel
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');

$otherheight = $slideheight;

$csswrapperwidth=$slidewidth;
$csswrapperheight=$slideheight;

// prepare the CSS
$css = '/* Carousel */

.carousel-container {
	background: '.$carbkgr.';
	padding: 10px 37px;
	border-radius: 10px/90px;
	box-shadow: 
		0 1px 3px rgba(0, 0, 0, 0.1), 
		inset -2px 0 3px 2px rgba(255, 255, 255, 0.2), 
		inset 2px 0 3px 2px rgba(255, 255, 255, 0.2), 
		inset -10px 0 10px 1px rgba(155, 155, 155, 0.1), 
		inset 10px 0 10px 1px rgba(155, 155, 155, 0.1);
}

.carousel_item{
	width: 100%;
	border:1px solid '.$bordercol.';
	position:relative;
	overflow:hidden;
	cursor:pointer;
	height:'.$slideheight.'px;
	color:#fff;
	padding-left: 10px;
	margin-left: -17px;
	padding-right: 10px;
	margin-right: -10px;
	text-shadow:1px 1px 1px #000;
	background:'.$gradend.';
	background:
		-webkit-gradient(
			linear,
			left top,
			left bottom,
			from('.$gradstart.'),
			to('.$gradend.')
		);
	background:
		-moz-linear-gradient(
			top,
			'.$gradstart.',
			'.$gradend.'
		);
	-moz-box-shadow:1px 1px 3px #cccccc;
	-webkit-box-shadow:1px 1px 3px #cccccc;
	box-shadow:1px 1px 3px #cccccc;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	border-radius:5px;
}
';

// add the CSS to the document
$doc =& JFactory::getDocument();
$doc->addStyleDeclaration($css);




?>

<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">
	<div class="carousel-container" style="padding-right: 25px;">
		<div class="carousel_item">

<script type="text/javascript">
// <![CDATA[

/***********************************************
* Conveyor belt slideshow script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/


//Specify the slider's width (in pixels)
var sliderwidth="100%"
//Specify the slider's height
var sliderheight="<?php echo $otherheight;?>px"
//Specify the slider's slide speed (larger is faster 1-10)
var slidespeed=<?php echo $slidespeed;?>
//configure background color:
slidebgcolor=""

//Specify the slider's images
var leftrightslide=new Array()
var finalslide=''

			<?php
			$k = 0;
			$count = 0;
			for ($i=0, $n=count( $items ); $i < $n; $i++) {

				$item = $items[$i];

				$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

				if(!EZRealtyFHelper::getTheImage($item->id) ){
					$image = JURI::root()."components/com_ezrealty/assets/images/nothumb.png";
				} else {
					$image = EZRealtyFHelper::convertModuleImage ($item->id);
				}

				?>

				leftrightslide[<?php echo $i;?>]='<a href="<?php echo $link;?>"><img src="<?php echo $image;?>" style="height:<?php echo $otherheight;?>px;" title="" alt="" /></a>'

			<?php } ?>


//Specify gap between each image (use HTML):
var imagegap=" "

//Specify pixels gap between each slideshow rotation (use integer):
var slideshowgap=<?php echo $rowgap;?>


////NO NEED TO EDIT BELOW THIS LINE////////////

var copyspeed=slidespeed
leftrightslide='<nobr>'+leftrightslide.join(imagegap)+'</nobr>'
var iedom=document.all||document.getElementById
if (iedom)
document.write('<span id="temp" style="visibility:hidden; position:absolute; top:-100px; left:-9000px; padding-bottom: 20px;">'+leftrightslide+'</span>')
var actualwidth=''
var cross_slide, ns_slide

function fillup(){
if (iedom){
cross_slide=document.getElementById? document.getElementById("test2") : document.all.test2
cross_slide2=document.getElementById? document.getElementById("test3") : document.all.test3
cross_slide.innerHTML=cross_slide2.innerHTML=leftrightslide
actualwidth=document.all? cross_slide.offsetWidth : document.getElementById("temp").offsetWidth
cross_slide2.style.left=actualwidth+slideshowgap+"px"
}
else if (document.layers){
ns_slide=document.ns_slidemenu.document.ns_slidemenu2
ns_slide2=document.ns_slidemenu.document.ns_slidemenu3
ns_slide.document.write(leftrightslide)
ns_slide.document.close()
actualwidth=ns_slide.document.width
ns_slide2.left=actualwidth+slideshowgap
ns_slide2.document.write(leftrightslide)
ns_slide2.document.close()
}
lefttime=setInterval("slideleft()",30)
}

function slideleft(){
if (iedom){
if (parseInt(cross_slide.style.left)>(actualwidth*(-1)+8))
cross_slide.style.left=parseInt(cross_slide.style.left)-copyspeed+"px"
else
cross_slide.style.left=parseInt(cross_slide2.style.left)+actualwidth+slideshowgap+"px"

if (parseInt(cross_slide2.style.left)>(actualwidth*(-1)+8))
cross_slide2.style.left=parseInt(cross_slide2.style.left)-copyspeed+"px"
else
cross_slide2.style.left=parseInt(cross_slide.style.left)+actualwidth+slideshowgap+"px"

}
else if (document.layers){
if (ns_slide.left>(actualwidth*(-1)+8))
ns_slide.left-=copyspeed
else
ns_slide.left=ns_slide2.left+actualwidth+slideshowgap

if (ns_slide2.left>(actualwidth*(-1)+8))
ns_slide2.left-=copyspeed
else
ns_slide2.left=ns_slide.left+actualwidth+slideshowgap
}
}


if (iedom||document.layers){
with (document){
document.write('<table style="width: 100%; padding: 0px; border-width: 1px #39b44a;"><tr><td>')
if (iedom){
write('<div style="position:relative;width:'+sliderwidth+';height:'+sliderheight+';overflow:hidden">')
write('<div style="position:absolute;width:'+sliderwidth+';height:'+sliderheight+';background-color:'+slidebgcolor+'" onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed">')
write('<div id="test2" style="position:absolute;left:0px;top:-20px"></div>')
write('<div id="test3" style="position:absolute;left:-1000px;top:-20px"></div>')
write('</div></div>')
}
else if (document.layers){
write('<ilayer width='+sliderwidth+' height='+sliderheight+' name="ns_slidemenu" bgColor='+slidebgcolor+'>')
write('<layer name="ns_slidemenu2" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
write('<layer name="ns_slidemenu3" left=0 top=0 onMouseover="copyspeed=0" onMouseout="copyspeed=slidespeed"></layer>')
write('</ilayer>')
}
document.write('</td></tr></table>')
}
}
// ]]>

</script>

		</div> 
	</div> 
</div>
