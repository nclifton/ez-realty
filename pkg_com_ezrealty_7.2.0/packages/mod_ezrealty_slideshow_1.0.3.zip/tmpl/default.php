<?php

/**
* Module: EZ Realty Slideshow
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 1.0.3
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');
require_once (JPATH_SITE.'/administrator/components/com_ezrealty/assets/helper.php' );

	$toppos = "top:-8px;";
	$leftpos = "left:-8px;";

// prepare the CSS
$css = '/* width of content scroller pane */

#ribbon {
	position:absolute;
	'.$toppos.'
	'.$leftpos.'
	z-index:500;
}

';

// add the CSS to the document
$doc =& JFactory::getDocument();
$doc->addStyleDeclaration($css);


?>

<?php if ($disjquery == 0){ ?>
	<script type="text/javascript" src="<?php echo JURI::root();?>/components/com_ezrealty/assets/jquery/jquery-1.8.3.min.js"></script>
<?php } ?>

<script type="text/javascript" src="<?php echo JURI::root();?>/modules/mod_ezrealty_slideshow/assets/scripts/jquery.mobile.customized.min.js"></script>
<script type="text/javascript" src="<?php echo JURI::root();?>/modules/mod_ezrealty_slideshow/assets/scripts/jquery.easing.1.3.js"></script> 
<script type="text/javascript" src="<?php echo JURI::root();?>/modules/mod_ezrealty_slideshow/assets/scripts/camera.min.js"></script> 
    
<script>
	jQuery.noConflict();

	jQuery(function(){

		jQuery('#camera_wrap_2').camera({
			height: '<?php echo $height;?>',
			minHeight: '<?php echo $minHeight;?>',
			easing: '<?php echo $easing;?>',
			fx: '<?php echo $fx;?>',
			loader: '<?php echo $loader;?>',
			loaderColor: '<?php echo $loaderColor;?>',
			loaderBgColor: '<?php echo $loaderBgColor;?>',
			loaderOpacity: '<?php echo $loaderOpacity;?>',
			time: '<?php echo $time;?>',
			transperiod: '<?php echo $transperiod;?>',
			pagination: false,
			thumbnails: false
		});

	});
</script>

<div class="moduletable<?php echo $moduleclass_sfx;?>">
	<div class="fluid_container">

		<?php if ($imgoverlay) { ?>
			<img src="<?php echo JURI::root();?>modules/mod_ezrealty_slideshow/assets/overlays/<?php echo $imgoverlay;?>-ribbon.png" alt="Ribbon" id="ribbon" />
		<?php }  ?>

		<div class="camera_wrap camera_black_skin" id="camera_wrap_2">

			<?php
			if ($imgsource == 2) {

				$pictures = glob("images/slideshow/*.jpg"); 
				$no_pictures = count($pictures)-1;  // was missing ;
				$limit = $no_pictures-3;            // was missing ;
				for( $i = $no_pictures; $i >= $limit; $i--){

				?>

					<div data-thumb="<?php echo JURI::root().$pictures[$i];?>" data-src="<?php echo JURI::root().$pictures[$i];?>">
					</div>

				<?php

				}

			} else {

				$num_items=ceil( count( $items ) / 1 );
				if ($num_items > 0) {

					foreach ( $items as $item ) {

						//clean up the title

						$item->adline = preg_replace(array('/&/', '/</', '/>/', '/"/'), array('&amp;', '&lt;', '&gt;', '&quot;'), $item->adline);
						$item->adline = str_replace( "'", "&#039;", $item->adline );
						$item->adline = str_replace( "\r\n", " ", $item->adline );
						$whichtitle = $item->adline;

						//clean up the description

						$item->smalldesc = preg_replace(array('/&/', '/</', '/>/', '/"/'), array('&amp;', '&lt;', '&gt;', '&quot;'), $item->smalldesc);
						$item->smalldesc = str_replace( "'", "&#039;", $item->smalldesc );
						$item->smalldesc = str_replace( "\r\n", " ", $item->smalldesc );
						$whichdesc = $item->smalldesc;

						if ($imgsource == 1){
							$image = JURI::root()."images/ezrealty/panorama/".$item->panorama;
						} else {
							if(!EZRealtyFHelper::getTheImage($item->id) ){
								$image = JURI::root()."components/com_ezrealty/assets/images/noimage.png";
							} else {
								$image = EZRealtyFHelper::convertModuleImage ($item->id);
								$image = str_replace( "th/", "", $image );
							}
						}

						$propertylink = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

						?>
						<div data-thumb="<?php echo $image;?>" data-src="<?php echo $image;?>">
							<?php if ($listinginfo < 3){ ?>
								<div class="camera_caption fadeFromBottom">
									<?php if ($listinginfo != 2) { ?><a href="<?php echo $propertylink;?>"><div class="ezslide-title<?php echo $titlesize;?>"><?php echo $whichtitle;?></div></a><?php } ?>
									<?php if ($listinginfo != 1) { ?><?php echo $whichdesc;?> ... <a href="<?php echo $propertylink;?>"><?php echo JText::_('MOD_EZREALTY_READMORE');?></a><?php } ?>
								</div>
							<?php } ?>
						</div>
					<?php

					}
				}
			}

			?>

		</div><!-- #camera_wrap -->
	</div>
</div>
