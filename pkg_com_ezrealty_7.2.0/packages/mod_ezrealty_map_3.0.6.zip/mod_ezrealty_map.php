<?php

/**
* Module: EZ Realty Map
* FileName: mod_ezrealty_map.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

# Kill error reporting
error_reporting(0);

$ezrparams = JComponentHelper::getParams ('com_ezrealty');
$db =& JFactory::getDBO();

$user = JFactory::getUser();
$groups = implode(',', $user->getAuthorisedViewLevels());

$path = JURI::root();

$layout 			= $params->get( 'layout' );
$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );
$cache 				= intval( $params->get( 'cache', 0 ) );

$usealtmap 			= intval( $params->get( 'usealtmap', 0 ) );
$maplang 			= $params->get( 'maplang', 'ru-RU' ) ;
$usestreetview 		= intval( $params->get( 'usestreetview', 0 ) );
$listingstype 		= intval( $params->get( 'listingstype', 0 ) );
$listingorder 		= intval( $params->get( 'listingorder', 0 ) );
$count 				= intval( $params->get( 'count', 5 ) );
$reflistcust1	 	= intval( $params->get( 'reflistcust1', 0 ) );
$listcust1 			= $params->get( 'listcust1' ) ;
$reflistcat	 		= intval( $params->get( 'reflistcat', 0 ) );
$listcat	 		= intval( $params->get( 'listcat', 0 ) );
$reflistsuburb		= intval( $params->get( 'reflistsuburb', 0 ) );
$listsuburb	 		= intval( $params->get( 'listsuburb', 0 ) );
$refliststate		= intval( $params->get( 'refliststate', 0 ) );
$liststate	 		= intval( $params->get( 'liststate', 0 ) );
$reflistcountry		= intval( $params->get( 'reflistcountry', 0 ) );
$listcountry		= intval( $params->get( 'listcountry', 0 ) );
$titlesource 		= intval( $params->get( 'titlesource', 0 ) );
$maplat 			= $params->get( 'maplat' );
$maplong 			= $params->get( 'maplong' );
$mapres 			= $params->get( 'mapres' );
$mapheight 			= $params->get( 'mapheight' );
$control_size 		= $params->get( 'control_size' );


$where = array();


if ($reflistcust1){
	$where[] = 'a.custom1 = "'.$db->getEscaped($listcust1, true ).'"';
}
if ($reflistcat){
	$where[] = 'pc.category_id = '.$listcat;
}
if ($reflistsuburb){
	$where[] = 'a.locid = '.$listsuburb;
}
if ($refliststate){
	$where[] = 'a.stid = '.$liststate;
}
if ($reflistcountry){
	$where[] = 'a.cnid = '.$listcountry;
}


if ($listingstype == 1){
	$where[] = 'a.featured = 1';
} else if ($listingstype == 2){
	$where[] = 'a.sold = 5';
} else if ($listingstype == 3){
	$getnow = date("Y-m-d");
	$where[] = '(a.ohdate >= "'.$getnow.'" OR a.ohdate2 >= "'.$getnow.'")';
} else if ($listingstype == 4){
	$where[] = "a.type = 4 AND a.aucdate != '0000-00-00'";
} else if ($listingstype == 5){
	$where[] = 'a.type = 1';
} else if ($listingstype == 6){
	$where[] = 'a.type = 2';
} else if ($listingstype == 7){
	$where[] = 'a.type = 3';
} else if ($listingstype == 8){
	$where[] = 'a.type = 5';
} else if ($listingstype == 9){
	$where[] = 'a.type = 6';
} else if ($listingstype == 10){
	$where[] = 'a.type = 7';
} else {
}

if ($ezrparams->get( 'er_expmgmt')==1 ) {
	$currentdate=mktime(0, 0, 0, date("m"), date("d"), date("Y"));
	$where[] = 'a.expdate>'.$currentdate;
}

if (JFactory::getApplication()->getLanguageFilter()) {
	$where[] = 'a.language in (' . $db->Quote(JFactory::getLanguage()->getTag()) . ',' . $db->Quote('*') . ')';
}

$where[] = 'ac.access IN (' . $groups . ')';
$where[] = 'ac.published = 1';
$where[] = 'a.published = 1';

$where 		= ( count( $where ) ? ' WHERE '. implode( ' AND ', $where ) : '' );

if ($listingorder == 1){
	$whichorder = " ORDER BY RAND()";
} else if ($listingorder == 2){
	$whichorder = " ORDER BY a.price DESC";
} else if ($listingorder == 3){
	$whichorder = " ORDER BY a.price ASC";
} else {
	$whichorder = " ORDER BY a.id DESC";
}


$howmany = ' LIMIT '. $count;


$query = ' SELECT distinct (a.id),a.*, cc.name AS category, dd.ezcity AS proploc, ee.name AS statename, ff.name AS cnname, '
.' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(\':\', a.id, a.alias) ELSE a.id END as slug, '
.' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(\':\', cc.id, cc.alias) ELSE cc.id END as catslug '
.' FROM #__ezrealty AS a'
.' INNER JOIN #__ezrealty_incats AS pc ON pc.property_id = a.id'
.' LEFT JOIN #__ezrealty_catg AS cc ON cc.id = a.cid'
.' LEFT JOIN #__ezrealty_catg as ac on ac.id = pc.category_id'
.' LEFT JOIN #__ezrealty_locality AS dd ON dd.id = a.locid'
.' LEFT JOIN #__ezrealty_state AS ee ON ee.id = a.stid'
.' LEFT JOIN #__ezrealty_country AS ff ON ff.id = a.cnid'
.' LEFT JOIN #__ezrealty_images AS ic ON ic.propid = a.id'
. $where
. ' GROUP BY a.id'
. $whichorder
. $howmany
;
$db->setQuery( $query );

//echo $query;

$items = $db->loadObjectList();

if ($db->getErrorNum()) {
	echo $db->stderr();
	return false;
}

$document =& JFactory::getDocument();

$document->addStyleSheet("modules/mod_ezrealty_map/assets/style.css",'text/css',"screen");

$document->addScript("http://maps.googleapis.com/maps/api/js?sensor=false");
$document->addScript("components/com_ezrealty/assets/includes.js");

require JModuleHelper::getLayoutPath('mod_ezrealty_map', $params->get('layout', 'default'));

?>
