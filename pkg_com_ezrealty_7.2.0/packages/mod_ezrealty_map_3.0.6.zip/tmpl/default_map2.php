<?php

/**
* Module: EZ Realty Map
* FileName: default_map2.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

$imgsize = $ezrparams->get( 'er_thumbwidth');
$readmore = JText::_('MOD_EZREALTY_READMORE');
$propid = JText::_('MOD_EZREALTY_PROPID');

if ($ezrparams->get( 'distortimg') && $ezrparams->get( 'thumbheight')){
	$theheight = "height=\"".$ezrparams->get( 'thumbheight')."px\"";
} else {
	$theheight = "";
}

// prepare the CSS
$ezmapstyle = '/* variable mapping style class to get around single style problems */

#map_canvas-'.$module->id.' img,
.google-maps img {
  max-width: none !important;
}

';

// add the CSS to the document
$doc =& JFactory::getDocument();
$doc->addStyleDeclaration($ezmapstyle);

?>

<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">

<div id="map_canvas-<?php echo $module->id;?>" style="position:relative; width: 100%; height: <?php echo $mapheight;?>px"></div>

	<?php if ( $ezrparams->get( 'er_usealtmap' ) < 2 ){?>
		<?php echo EZRealtyFHelper::convertMapIcons(); ?>
	<?php } ?>

	<script type="text/javascript">
	var locations = [
		<?php foreach ($items as $item){
			$iconcount = $item->count;
			$whichicon = JURI::root()."components/com_ezrealty/assets/images/map".$item->type.".png";

			$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

			//clean any line breaks
			$mapdesc = str_replace( "\r\n", " ", $item->smalldesc );

			if ($item->declat && $item->declong && $item->viewad){ ?>
				['<div class="row-fluid"><div class="span4"><?php if(!EZRealtyFHelper::getTheImage($item->id) ){ ?><a href="<?php echo $link;?>"><img class="span12 thumbnail" src="<?php echo JURI::root(); ?>components/com_ezrealty/assets/images/nothumb.png" /></a><?php } else { ?><a href="<?php echo $link;?>"><img class="span12 thumbnail" src="<?php echo EZRealtyFHelper::convertMapImage ($item->id); ?>" /></a><?php } ?></div><div class="span8 ezitem-smallleftpad"><div class="row-fluid"><div class="span12 ezitem-maptitle <?php echo $ezrparams->get( 'titlecolor' );?>"><?php echo addslashes($item->adline);?></div></div><div class="ezitem-iconbkgr"><span class="ezitem-leftpad"><?php echo EZRealtyFHelper::textIcons ($item->bedrooms, $item->bathrooms, $item->parkingGarage, $item->squarefeet, ""); ?></span></div><p><?php echo addslashes($mapdesc); ?> ... <a href="<?php echo $link; ?>"><?php echo $readmore;?></a></p></div></div>', <?php echo $item->declat;?>, <?php echo $item->declong;?>, <?php echo $iconcount;?>, '<?php echo $whichicon;?>'],
			<?php }
		} ?>
	];

	var map = new google.maps.Map(document.getElementById('map_canvas-<?php echo $module->id;?>'), {
		zoom: <?php echo $mapres;?>,
		center: new google.maps.LatLng(<?php echo $maplat;?>, <?php echo $maplong;?>),
		panControl: true,
		zoomControl: true,
		zoomControlOptions: {
			style: google.maps.ZoomControlStyle.<?php echo $params->get( 'control_size' );?>
		},
		streetViewControl: <?php if ( $params->get( 'usestreetview' ) ){ ?>true<?php } else { ?>false<?php } ?>,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow();

	var marker, i;

	for (i = 0; i < locations.length; i++) {

		marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][1], locations[i][2]),
			map: map,
			icon: new google.maps.MarkerImage(locations[i][4])
		});

		google.maps.event.addListener(marker, 'click', (function(marker, i) {
			return function() {
				infowindow.setContent(locations[i][0]);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
</script>

</div>
<br />