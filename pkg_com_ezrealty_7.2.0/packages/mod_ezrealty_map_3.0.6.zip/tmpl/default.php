<?php

/**
* Module: EZ Realty Map
* FileName: default.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

if ( $ezrparams->get( 'enable_bootstrap' ) ){

?>

<link rel="stylesheet" href="<?php echo JURI::root(); ?>components/com_ezrealty/assets/bootstrap.css" type="text/css" />

<?php } ?>

<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">

	<?php if ($usealtmap == 2){
		require ( JPATH_SITE . '/modules/mod_ezrealty_map/tmpl/default_map3.php' );
	} else if ($usealtmap == 1){
		require ( JPATH_SITE . '/modules/mod_ezrealty_map/tmpl/default_map2.php' );
	} else {
		require ( JPATH_SITE . '/modules/mod_ezrealty_map/tmpl/default_map1.php' );
	}

?>

</div>
