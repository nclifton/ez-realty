<?php

/**
* Module: EZ Realty Map
* FileName: default_map1.php
* Date: 24th June 2014
* License: Creative Commons GNU GPL, see http://creativecommons.org/licenses/GPL/2.0/ for full license
* Script Version #: 3.0.6
* EZ Realty Version #: 7.2.0
* @author  Kathy Strickland (aka PixelBunyiP) - Raptor Services <kathy@raptorservices.com>
* @copyright Copyright (C) 2006 - 2014 Raptor Developments Pty Ltd T/as Raptor Services-All rights reserved
**/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

require_once (JPATH_SITE.'/components/com_ezrealty/helpers/route.php');
require_once (JPATH_SITE.'/components/com_ezrealty/helpers/helper.php');

$ezrparams = JComponentHelper::getParams ('com_ezrealty');

$imgsize = $ezrparams->get( 'er_thumbwidth');
$readmore = JText::_('MOD_EZREALTY_READMORE');
$propid = JText::_('MOD_EZREALTY_PROPID');

if ($ezrparams->get( 'distortimg') && $ezrparams->get( 'thumbheight')){
	$theheight = "height=\"".$ezrparams->get( 'thumbheight')."px\"";
} else {
	$theheight = "";
}

// prepare the CSS
$ezmapstyle = '/* variable mapping style class to get around single style problems */

#map_canvas-'.$module->id.' img,
.google-maps img {
  max-width: none !important;
}

';

// add the CSS to the document
$doc =& JFactory::getDocument();
$doc->addStyleDeclaration($ezmapstyle);

?>
<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">

<script type="text/javascript">
// <![CDATA[

  var modmap;
  var panorama2;
  var centerPlace2 = new google.maps.LatLng(<?php echo $maplat;?>, <?php echo $maplong;?>);

<?php foreach ($items as $item){
	if ($item->declat && $item->declong && $item->viewad){ ?>
		var modpropListing<?php echo $item->id;?> = new google.maps.LatLng(<?php echo $item->declat;?>, <?php echo $item->declong;?>);
<?php
	}
} ?>

  function initEzrMapMod() {

    // Set up the map
    var mapOptions2 = {
		zoom: <?php echo $mapres;?>,
		center: new google.maps.LatLng(<?php echo $maplat;?>, <?php echo $maplong;?>),
		panControl: true,
		zoomControl: true,
		zoomControlOptions: {
			style: google.maps.ZoomControlStyle.<?php echo $params->get( 'control_size' );?>
		},
		streetViewControl: <?php if ( $params->get( 'usestreetview' ) ){ ?>true<?php } else { ?>false<?php } ?>,
		mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    modmap = new google.maps.Map(document.getElementById('map_canvas-<?php echo $module->id;?>'), mapOptions2);

    // Setup the markers on the map

<?php foreach ($items as $item){

	$iconcount = $item->count;
	if ($item->declat && $item->declong && $item->viewad){

		$link = JRoute::_(EzrealtyHelperRoute::getEzrealtyRoute($item->slug, $item->catslug, '', ''));

		if ($titlesource == 1){
			$whichtitle = $item->proploc;
		} if ($titlesource == 2){
			$whichtitle = $item->adline;
		}

		//clean any line breaks
        $mapdesc = str_replace( "\r\n", " ", $item->smalldesc );


?>

    var contentString<?php echo $item->id;?> = '<div class="row-fluid">'+
        '<div class="span4">'+
		<?php if(!EZRealtyFHelper::getTheImage($item->id) ){ ?>
        '<a href="<?php echo $link;?>"><img class="span12 thumbnail" src="<?php echo JURI::root(); ?>components/com_ezrealty/assets/images/nothumb.png" /></a>'+
		<?php } else { ?>
        '<a href="<?php echo $link;?>"><img class="span12 thumbnail" src="<?php echo EZRealtyFHelper::convertMapImage ($item->id); ?>" /></a>'+
		<?php } ?>
        '</div><div class="span8 ezitem-smallleftpad">'+
        '<div class="row-fluid"><div class="span12 ezitem-maptitle <?php echo $ezrparams->get( 'titlecolor' );?>"><?php echo addslashes($item->adline);?></div></div>'+
        '<div class="ezitem-iconbkgr"><span class="ezitem-leftpad"><?php echo EZRealtyFHelper::textIcons ($item->bedrooms, $item->bathrooms, $item->parkingGarage, $item->squarefeet, ""); ?></span></div>'+
        '<p><?php echo addslashes($mapdesc); ?> ... <a href="<?php echo $link; ?>"><?php echo $readmore;?></a></p>'+
        '</div>'+
        '</div>';


        
    var infowindow<?php echo $item->id;?> = new google.maps.InfoWindow({
        content: contentString<?php echo $item->id;?>
    });

    var modpropListing<?php echo $item->id;?>MarkerImage =
        new google.maps.MarkerImage(
            '<?php echo JURI::root();?>components/com_ezrealty/assets/images/map<?php echo $item->type;?>.png');
    var modpropListing<?php echo $item->id;?>Marker = new google.maps.Marker({
        position: modpropListing<?php echo $item->id;?>,
        map: modmap,
        icon: modpropListing<?php echo $item->id;?>MarkerImage,
        title: '<?php echo $propid;?> <?php echo $item->id;?>:- <?php echo addslashes($whichtitle);?>'
    });

    google.maps.event.addListener(modpropListing<?php echo $item->id;?>Marker, 'click', function() {
      infowindow<?php echo $item->id;?>.open(modmap,modpropListing<?php echo $item->id;?>Marker);
    });

<?php
	}
} ?>

  }

// ]]>
</script>

	<div id="map_canvas-<?php echo $module->id;?>" style="position:relative;width: <?php echo $mapwidth;?>px; height: <?php echo $mapheight;?>px"></div>

	<?php if ( $ezrparams->get( 'er_usealtmap' ) < 2 ){?>
		<?php echo EZRealtyFHelper::convertMapIcons(); ?>
	<?php } ?>

</div>
<br />