
************************************************************************

			The standard EZ Realty package

************************************************************************



About the contents of this package:-



1. pkg_com_ezrealty_xxxx.zip


This package contains the EZ Realty packages - ie. the EZ Realty component and its modules.  
Install the package onto your Joomla 3x site using the Joomla extension installer.


========================================================================


2. pkg_com_ezfeeds_xxxx.zip


This package contains the EZ Feeds package - ie. the EZ Feeds component.  
Install the package onto your Joomla 3x site using the Joomla extension installer.


========================================================================


3. pkg_com_ezwatchlists_xxxx_lite.zip


This package contains the EZ Watchlists Lite package - ie. the EZ Watchlists Lite component.  
Install the package onto your Joomla 3x site using the Joomla extension installer.


========================================================================


4. pkg_com_realtybookings_xxxx_lite.zip


This package contains the Realty Bookings Lite package - ie. the Realty Bookings Lite component.  
Install the package onto your Joomla 3x site using the Joomla extension installer.


========================================================================


5. ezrealty_V7_falang_contentelements.zip


This package contains the Falang contentelement files for EZ Realty.  
Unzip this package, and read the instructions contained inside it on how to install the files.


========================================================================


6. ezrealty_V7_jreviews_file.zip


This package contains the EZ Realty files used by jReviews.  
Unzip this package, and read the instructions contained inside it on how to install the files.


========================================================================

